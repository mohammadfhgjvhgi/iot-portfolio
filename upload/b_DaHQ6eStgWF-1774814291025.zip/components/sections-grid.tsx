import Link from "next/link"
import {
  Cpu,
  BookOpen,
  Gauge,
  Cable,
  Code2,
  MonitorDown,
  Users,
  Lightbulb,
} from "lucide-react"
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const sections = [
  {
    href: "/assistant",
    icon: Lightbulb,
    title: "مساعد المشاريع الذكي",
    description: "اختر مشروعًا جاهزًا أو اطلب توليد فكرة مشروع بناءً على مدخلاتك الخاصة.",
    accent: "from-primary/20 to-primary/5",
  },
  {
    href: "/boards",
    icon: Cpu,
    title: "دليل اللوحات",
    description: "مقارنة شاملة بين Arduino و ESP32 و Raspberry Pi مع الصور والمميزات.",
    accent: "from-chart-2/20 to-chart-2/5",
  },
  {
    href: "/learning",
    icon: BookOpen,
    title: "المسار التعليمي",
    description: "دروس متدرجة من الصفر حتى الاحتراف في عالم الأنظمة المدمجة.",
    accent: "from-chart-4/20 to-chart-4/5",
  },
  {
    href: "/sensors",
    icon: Gauge,
    title: "موسوعة الحساسات والقطع",
    description: "تعريف بكل القطع الإلكترونية وطريقة عملها مع أمثلة تطبيقية.",
    accent: "from-chart-5/20 to-chart-5/5",
  },
  {
    href: "/wiring",
    icon: Cable,
    title: "دليل التوصيل والإرشاد",
    description: "شروحات تفاعلية لطرق الربط مع نصائح تقنية لتجنب حرق القطع.",
    accent: "from-destructive/20 to-destructive/5",
  },
  {
    href: "/code-generator",
    icon: Code2,
    title: "بوت البرمجة",
    description: "اكتب وصف مشروعك ودع البوت يولّد لك الكود البرمجي الجاهز.",
    accent: "from-primary/20 to-primary/5",
  },
  {
    href: "/environments",
    icon: MonitorDown,
    title: "بيئات البرمجة",
    description: "شرح تحميل وتشغيل Arduino IDE و VS Code و MicroPython خطوة بخطوة.",
    accent: "from-chart-2/20 to-chart-2/5",
  },
  {
    href: "/community",
    icon: Users,
    title: "ملتقى المبدعين",
    description: "شارك مشاريعك وتبادل الخبرات مع مجتمع الطلاب والمبتكرين.",
    accent: "from-chart-4/20 to-chart-4/5",
  },
]

export function SectionsGrid() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 lg:py-24">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold text-foreground">استكشف الأقسام</h2>
        <p className="mt-3 text-lg text-muted-foreground">
          كل ما تحتاجه لتعلم الأنظمة المدمجة وبناء مشاريع مبتكرة
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {sections.map((section) => (
          <Link key={section.href} href={section.href} className="group">
            <Card className="h-full border-border bg-card transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5">
              <CardHeader>
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-lg bg-secondary text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <section.icon className="h-5 w-5" />
                </div>
                <CardTitle className="text-base text-foreground">{section.title}</CardTitle>
                <CardDescription className="text-sm leading-relaxed text-muted-foreground">
                  {section.description}
                </CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  )
}
