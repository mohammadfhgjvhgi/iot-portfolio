"use client"

import { useState } from "react"
import { Heart, MessageCircle, Share2, Send, ImagePlus, User, Users } from "lucide-react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"

interface Post {
  id: number
  author: string
  authorInitials: string
  time: string
  content: string
  likes: number
  comments: number
  tags: string[]
  liked: boolean
}

export function CommunityFeed() {
  const [posts, setPosts] = useState<Post[]>([])
  const [newPostContent, setNewPostContent] = useState("")

  function handleLike(postId: number) {
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
          : post
      )
    )
  }

  function handleSubmitPost() {
    if (!newPostContent.trim()) return
    const newPost: Post = {
      id: Date.now(),
      author: "زائر",
      authorInitials: "ز",
      time: "الآن",
      content: newPostContent,
      likes: 0,
      comments: 0,
      tags: [],
      liked: false,
    }
    setPosts([newPost, ...posts])
    setNewPostContent("")
  }

  return (
    <div className="flex flex-col gap-6">
      {/* New Post */}
      <Card className="border-border bg-card">
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <Avatar className="h-10 w-10 shrink-0">
              <AvatarFallback className="bg-secondary text-foreground">
                <User className="h-5 w-5" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="شارك مشروعك أو اطرح سؤالك..."
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="min-h-[80px] resize-none border-border bg-secondary text-foreground placeholder:text-muted-foreground"
              />
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" className="text-muted-foreground" disabled>
                    <ImagePlus className="ml-1 h-4 w-4" />
                    صورة
                  </Button>
                </div>
                <Button size="sm" onClick={handleSubmitPost} disabled={!newPostContent.trim()}>
                  <Send className="ml-1 h-4 w-4" />
                  نشر
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Empty state */}
      {posts.length === 0 && (
        <Card className="border-border bg-card">
          <CardContent className="flex flex-col items-center py-16 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">ملتقى المبدعين</h3>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">
              لا توجد منشورات بعد. كن أول من يشارك مشروعه أو يطرح سؤالاً!
              شارك تجاربك مع لوحات Arduino و ESP32 وساعد الآخرين في التعلم.
            </p>
            <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground">
              <span>يمكنك مشاركة:</span>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge variant="secondary">مشاريعك</Badge>
                <Badge variant="secondary">أسئلة</Badge>
                <Badge variant="secondary">أفكار</Badge>
                <Badge variant="secondary">مشاكل وحلول</Badge>
                <Badge variant="secondary">نصائح</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Posts */}
      {posts.map((post) => (
        <Card key={post.id} className="border-border bg-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">
                  {post.authorInitials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <span className="text-sm font-semibold text-foreground">{post.author}</span>
                <p className="text-xs text-muted-foreground">{post.time}</p>
              </div>
            </div>
          </CardHeader>

          <CardContent>
            <p className="mb-3 text-sm leading-relaxed text-foreground">{post.content}</p>

            {post.tags.length > 0 && (
              <div className="mb-4 flex flex-wrap gap-2">
                {post.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                ))}
              </div>
            )}

            <div className="flex items-center gap-4 border-t border-border pt-3">
              <button
                onClick={() => handleLike(post.id)}
                className={`flex items-center gap-1.5 text-sm transition-colors ${
                  post.liked ? "text-primary" : "text-muted-foreground hover:text-primary"
                }`}
                aria-label={post.liked ? "إلغاء الإعجاب" : "إعجاب"}
              >
                <Heart className={`h-4 w-4 ${post.liked ? "fill-current" : ""}`} />
                <span>{post.likes}</span>
              </button>
              <button className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
                <MessageCircle className="h-4 w-4" />
                <span>{post.comments}</span>
              </button>
              <button className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
                <Share2 className="h-4 w-4" />
                <span>مشاركة</span>
              </button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
