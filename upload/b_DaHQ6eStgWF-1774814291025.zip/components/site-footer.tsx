import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4">
        <p className="text-xs text-muted-foreground">
          جميع الحقوق محفوظة لدى{" "}
          <span className="font-semibold text-foreground">عمار مشارقة</span> و{" "}
          <span className="font-semibold text-foreground">محمد عقيلي</span>
        </p>
        <div className="flex items-center gap-4">
          <Link href="/about" className="text-xs text-muted-foreground transition-colors hover:text-primary">
            من نحن
          </Link>
          <Link href="/contact" className="text-xs text-muted-foreground transition-colors hover:text-primary">
            تواصل معنا
          </Link>
        </div>
      </div>
    </footer>
  )
}
