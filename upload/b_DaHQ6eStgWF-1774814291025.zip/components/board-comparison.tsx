"use client"

import { useState } from "react"
import { Cpu, Wifi, Zap, ChevronDown, ChevronUp, Search, Filter } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

interface Board {
  name: string
  family: string
  description: string
  features: string[]
  wifi: boolean
  bluetooth: boolean
  bestFor: string
}

const families = [
  {
    name: "عائلة أردوينو (Arduino Family)",
    description: "تُعد المدخل الأساسي للمبتدئين نظراً لسهولتها وتوفر مكتبات برمجية ضخمة لها.",
    color: "bg-primary",
    boards: [
      {
        name: "Arduino Uno R3",
        family: "Arduino",
        description: "اللوحة المعيارية الأكثر شهرة للتعلم.",
        features: ["معالج ATmega328P", "16 MHz", "14 دبوس رقمي", "6 دبوس تناظري", "USB-B"],
        wifi: false,
        bluetooth: false,
        bestFor: "الأفضل للمبتدئين والمشاريع المدرسية",
      },
      {
        name: "Arduino Uno R4 WiFi",
        family: "Arduino",
        description: "النسخة الأحدث التي تدمج معالج ARM القوي مع WiFi وبلوتوث ومصفوفة LED.",
        features: ["معالج ARM Cortex-M4", "48 MHz", "WiFi + بلوتوث", "مصفوفة LED 12x8", "USB-C"],
        wifi: true,
        bluetooth: true,
        bestFor: "تطوير مشاريع IoT مع سهولة Arduino",
      },
      {
        name: "Arduino Mega 2560",
        family: "Arduino",
        description: "توفر 54 دبوساً للإدخال والإخراج، مما يجعلها مثالية للروبوتات المعقدة.",
        features: ["معالج ATmega2560", "16 MHz", "54 دبوس رقمي", "16 دبوس تناظري", "256 KB Flash"],
        wifi: false,
        bluetooth: false,
        bestFor: "الروبوتات المعقدة والمشاريع الكبيرة",
      },
      {
        name: "Arduino Nano",
        family: "Arduino",
        description: "نسخة مصغرة جداً تُوضع مباشرة على لوحات التجارب (Breadboards).",
        features: ["معالج ATmega328P", "16 MHz", "حجم صغير جداً", "مناسب للبريدبورد", "Mini-USB"],
        wifi: false,
        bluetooth: false,
        bestFor: "المشاريع المدمجة وصغيرة الحجم",
      },
      {
        name: "Arduino Leonardo",
        family: "Arduino",
        description: "تتميز بدعم USB أصلي يسمح لها بمحاكاة لوحة المفاتيح أو الفأرة.",
        features: ["معالج ATmega32U4", "16 MHz", "USB أصلي (HID)", "20 دبوس رقمي", "محاكاة ماوس/كيبورد"],
        wifi: false,
        bluetooth: false,
        bestFor: "مشاريع محاكاة أجهزة الإدخال USB",
      },
      {
        name: "Arduino Due",
        family: "Arduino",
        description: "لوحة عالية الأداء تعمل بمعالج 32-بت للمشاريع التي تتطلب حسابات معقدة.",
        features: ["معالج ARM Cortex-M3", "84 MHz", "32-بت", "54 دبوس رقمي", "512 KB Flash"],
        wifi: false,
        bluetooth: false,
        bestFor: "المشاريع المتقدمة ومعالجة الإشارات",
      },
    ],
  },
  {
    name: "عائلة ESP (لوحات إنترنت الأشياء)",
    description: "تتميز بدمج الربط اللاسلكي وتعتبر 'خيول العمل' لمشاريع إنترنت الأشياء (IoT).",
    color: "bg-chart-2",
    boards: [
      {
        name: "ESP32 DevKit V1",
        family: "ESP",
        description: "اللوحة القياسية التي تدعم WiFi وبلوتوث ومعالج ثنائي النواة.",
        features: ["Xtensa ثنائي النواة", "240 MHz", "WiFi + بلوتوث", "520 KB RAM", "34 GPIO"],
        wifi: true,
        bluetooth: true,
        bestFor: "مشاريع IoT والمنزل الذكي",
      },
      {
        name: "ESP32-S3",
        family: "ESP",
        description: "مخصصة لتطبيقات الذكاء الاصطناعي (Edge AI) والتعرف على الصور والأوامر الصوتية.",
        features: ["Xtensa ثنائي النواة", "240 MHz", "WiFi + بلوتوث 5", "دعم AI/ML", "USB أصلي"],
        wifi: true,
        bluetooth: true,
        bestFor: "الذكاء الاصطناعي على الأجهزة (Edge AI)",
      },
      {
        name: "ESP32-CAM",
        family: "ESP",
        description: "لوحة مدمج بها كاميرا صغيرة ومنفذ لبطاقة ذاكرة.",
        features: ["ESP32-S", "كاميرا OV2640", "منفذ MicroSD", "WiFi", "فلاش LED"],
        wifi: true,
        bluetooth: true,
        bestFor: "المراقبة والتصوير عن بعد",
      },
      {
        name: "NodeMCU (ESP8266)",
        family: "ESP",
        description: "لوحة اقتصادية جداً توفر ربط WiFi للمشاريع البسيطة.",
        features: ["Tensilica L106", "80 MHz", "WiFi فقط", "سعر منخفض جداً", "11 GPIO"],
        wifi: true,
        bluetooth: false,
        bestFor: "مشاريع WiFi البسيطة والاقتصادية",
      },
      {
        name: "ESP32-C6",
        family: "ESP",
        description: "تدعم تقنيات حديثة مثل WiFi 6 وMatter للمنازل الذكية.",
        features: ["RISC-V", "160 MHz", "WiFi 6", "بلوتوث 5.3", "دعم Matter/Thread"],
        wifi: true,
        bluetooth: true,
        bestFor: "المنازل الذكية بأحدث التقنيات",
      },
    ],
  },
  {
    name: "عائلة STM32 (الفئة الاحترافية)",
    description: "تعتبر المعيار الذهبي في الصناعة والمشاريع التي تتطلب دقة وموثوقية عالية.",
    color: "bg-chart-5",
    boards: [
      {
        name: "STM32 Blue Pill",
        family: "STM32",
        description: "لوحة رخيصة جداً واسعة الانتشار لتعلم معالجات ARM.",
        features: ["ARM Cortex-M3", "72 MHz", "64 KB Flash", "20 KB RAM", "سعر منخفض"],
        wifi: false,
        bluetooth: false,
        bestFor: "تعلم معالجات ARM بسعر منخفض",
      },
      {
        name: "STM32 Black Pill",
        family: "STM32",
        description: "نسخة أسرع وأقوى من Blue Pill تدعم معالجة الإشارات الرقمية.",
        features: ["ARM Cortex-M4", "100 MHz", "512 KB Flash", "128 KB RAM", "USB-C"],
        wifi: false,
        bluetooth: false,
        bestFor: "معالجة الإشارات والمشاريع الصناعية",
      },
      {
        name: "STM32 Nucleo",
        family: "STM32",
        description: "اللوحات الرسمية للمطورين، تحتوي على مبرمج مدمج وتتوافق مع دروع أردوينو.",
        features: ["معالجات متنوعة", "مبرمج ST-Link مدمج", "توافق Arduino Shields", "أدوات احترافية", "دعم رسمي"],
        wifi: false,
        bluetooth: false,
        bestFor: "التطوير الاحترافي والصناعي",
      },
    ],
  },
  {
    name: "عائلة Raspberry Pi Pico",
    description: "لوحات مرنة جداً تعتمد على شريحة RP2040 ودعم MicroPython.",
    color: "bg-chart-4",
    boards: [
      {
        name: "Raspberry Pi Pico",
        family: "Pico",
        description: "اللوحة الأساسية ثنائية النواة التي تدعم لغة MicroPython.",
        features: ["RP2040 ثنائي النواة", "133 MHz", "264 KB RAM", "MicroPython + C/C++", "26 GPIO"],
        wifi: false,
        bluetooth: false,
        bestFor: "تعلم MicroPython والمشاريع المرنة",
      },
      {
        name: "Raspberry Pi Pico W",
        family: "Pico",
        description: "تضيف ميزة الربط اللاسلكي WiFi للوحة بيكو.",
        features: ["RP2040", "133 MHz", "WiFi 2.4GHz", "بلوتوث 5.2", "MicroPython"],
        wifi: true,
        bluetooth: true,
        bestFor: "مشاريع IoT باستخدام MicroPython",
      },
      {
        name: "Raspberry Pi Pico 2",
        family: "Pico",
        description: "الجيل الجديد الذي يستخدم شريحة RP2350 الأكثر قوة وأمناً.",
        features: ["RP2350", "150 MHz", "520 KB RAM", "أمان محسّن", "توافق مع Pico الأصلي"],
        wifi: false,
        bluetooth: false,
        bestFor: "مشاريع متقدمة تحتاج أداء أعلى",
      },
    ],
  },
  {
    name: "لوحات تخصصية أخرى",
    description: "لوحات متخصصة لتطبيقات محددة مثل الصوت، الأجهزة المحمولة، والبلوتوث.",
    color: "bg-chart-3",
    boards: [
      {
        name: "Teensy 4.0/4.1",
        family: "Teensy",
        description: "تتميز بسرعات فائقة تصل إلى 600 ميجاهرتز، المفضلة لمشاريع الصوت والموسيقى.",
        features: ["ARM Cortex-M7", "600 MHz", "1 MB RAM", "USB عالي السرعة", "معالجة صوت متقدمة"],
        wifi: false,
        bluetooth: false,
        bestFor: "مشاريع الصوت والموسيقى المتقدمة",
      },
      {
        name: "Adafruit Feather",
        family: "Adafruit",
        description: "نظام لوحات موحد الحجم، يحتوي كل منها على شاحن بطارية مدمج.",
        features: ["معالجات متنوعة", "شاحن بطارية LiPo", "حجم موحد", "إضافات متوافقة (FeatherWing)", "محمول"],
        wifi: false,
        bluetooth: false,
        bestFor: "المشاريع المحمولة التي تعمل بالبطارية",
      },
      {
        name: "Seeeduino XIAO",
        family: "Seeed",
        description: "لوحات متناهية الصغر بحجم الإبهام للأجهزة القابلة للارتداء والدرونات.",
        features: ["ARM Cortex-M0+", "48 MHz", "حجم الإبهام", "USB-C", "14 GPIO"],
        wifi: false,
        bluetooth: false,
        bestFor: "الأجهزة القابلة للارتداء والدرونات",
      },
      {
        name: "Nordic nRF52840",
        family: "Nordic",
        description: "متخصصة في تقنية البلوتوث منخفض الطاقة (BLE) والبطاريات التي تدوم لأشهر.",
        features: ["ARM Cortex-M4", "64 MHz", "بلوتوث 5 BLE", "استهلاك فائق الانخفاض", "NFC"],
        wifi: false,
        bluetooth: true,
        bestFor: "أجهزة البلوتوث منخفضة الطاقة",
      },
      {
        name: "PIC Microcontrollers",
        family: "Microchip",
        description: "منصة كلاسيكية من شركة Microchip لا تزال شائعة في الأنظمة الصناعية والسيارات.",
        features: ["8/16/32 بت", "منصة كلاسيكية", "موثوقية عالية", "MPLAB IDE", "انتشار صناعي واسع"],
        wifi: false,
        bluetooth: false,
        bestFor: "الأنظمة الصناعية وقطاع السيارات",
      },
    ],
  },
]

const allFamilyNames = ["الكل", ...families.map(f => f.name.split("(")[0].trim())]

export function BoardComparison() {
  const [search, setSearch] = useState("")
  const [selectedFamily, setSelectedFamily] = useState("الكل")
  const [expandedBoard, setExpandedBoard] = useState<string | null>(null)

  const filteredFamilies = families.filter(family => {
    if (selectedFamily !== "الكل" && !family.name.includes(selectedFamily.replace("عائلة ", ""))) {
      return false
    }
    if (search) {
      return family.boards.some(b =>
        b.name.toLowerCase().includes(search.toLowerCase()) ||
        b.description.includes(search)
      )
    }
    return true
  }).map(family => ({
    ...family,
    boards: search
      ? family.boards.filter(b =>
          b.name.toLowerCase().includes(search.toLowerCase()) ||
          b.description.includes(search)
        )
      : family.boards,
  }))

  return (
    <div className="flex flex-col gap-8">
      {/* Intro text */}
      <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
        <p className="text-sm leading-relaxed text-foreground">
          تُعرف لوحات التحكم الدقيق (<strong>MCUs</strong>) بأنها أنظمة حاسوبية مصغرة على شريحة واحدة،
          مُصممة لأداء مهام محددة واستهلاك طاقة ضئيل. وهي تختلف عن أجهزة الكمبيوتر الكاملة في أنها
          تُشغل برنامجاً واحداً في حلقة مستمرة. فيما يلي قائمة شاملة بجميع العائلات والأنواع:
        </p>
      </div>

      {/* Search and filter */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ابحث عن لوحة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-border bg-card pr-10 text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {["الكل", "أردوينو", "ESP", "STM32", "Pico", "تخصصية"].map((fam) => (
            <button
              key={fam}
              onClick={() => setSelectedFamily(fam === "الكل" ? "الكل" : fam)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                (selectedFamily === "الكل" && fam === "الكل") ||
                (selectedFamily !== "الكل" && fam !== "الكل" && selectedFamily.includes(fam))
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {fam}
            </button>
          ))}
        </div>
      </div>

      {/* Board families */}
      {filteredFamilies.map((family) => (
        <section key={family.name}>
          <div className="mb-4 flex items-center gap-3">
            <div className={`h-1 w-8 rounded-full ${family.color}`} />
            <div>
              <h2 className="text-xl font-bold text-foreground">{family.name}</h2>
              <p className="text-sm text-muted-foreground">{family.description}</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {family.boards.map((board) => {
              const isExpanded = expandedBoard === board.name
              return (
                <Card
                  key={board.name}
                  className="border-border bg-card transition-all hover:border-primary/30 hover:shadow-md cursor-pointer"
                  onClick={() => setExpandedBoard(isExpanded ? null : board.name)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base text-foreground">{board.name}</CardTitle>
                      <div className="flex items-center gap-1.5">
                        {board.wifi && (
                          <Wifi className="h-4 w-4 text-primary" />
                        )}
                        {board.bluetooth && (
                          <Zap className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    </div>
                    <CardDescription className="text-sm text-muted-foreground">
                      {board.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-3 flex flex-wrap gap-1.5">
                      {board.features.slice(0, isExpanded ? undefined : 3).map((f) => (
                        <Badge key={f} variant="secondary" className="text-xs">
                          {f}
                        </Badge>
                      ))}
                      {!isExpanded && board.features.length > 3 && (
                        <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                          +{board.features.length - 3}
                        </Badge>
                      )}
                    </div>
                    <div className="rounded-md bg-primary/5 px-3 py-2 text-xs font-medium text-primary">
                      {board.bestFor}
                    </div>
                    {isExpanded && (
                      <div className="mt-3 text-xs text-muted-foreground">
                        <span className="font-medium text-foreground">جميع المميزات: </span>
                        {board.features.join(" - ")}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </section>
      ))}

      {filteredFamilies.length === 0 && (
        <div className="py-12 text-center">
          <Cpu className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
          <p className="text-lg text-muted-foreground">لم يتم العثور على نتائج</p>
        </div>
      )}
    </div>
  )
}
