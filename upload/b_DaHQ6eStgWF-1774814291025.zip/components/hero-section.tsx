import { Cpu, Zap, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-card">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-20 -right-20 h-56 w-56 rounded-full bg-primary/3 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-16 lg:py-24">
        <div className="flex flex-col items-center text-center">
          <div className="mb-5 flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5">
            <Zap className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Arduino & AI Projects</span>
          </div>

          <h1 className="max-w-3xl text-balance text-3xl font-bold leading-tight text-foreground lg:text-5xl">
            مشاريع لوحات التحكم الدقيق
            <span className="block text-primary">الطلابية</span>
          </h1>

          <p className="mt-5 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground lg:text-lg">
            موقع تعليمي وتفاعلي شامل للأنظمة المدمجة والذكاء الاصطناعي.
            تعلّم من الصفر، اختر لوحتك، واكتشف عالم المشاريع الإلكترونية خطوة بخطوة.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button asChild size="lg" className="text-base font-semibold">
              <Link href="/learning">
                ابدأ التعلم الآن
                <ArrowLeft className="mr-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-base">
              <Link href="/boards">استكشف اللوحات</Link>
            </Button>
          </div>

          <div className="mt-12 flex flex-wrap items-center justify-center gap-6 lg:gap-12">
            {[
              { value: "20+", label: "لوحة تحكم" },
              { value: "50+", label: "حساس وقطعة" },
              { value: "100+", label: "مشروع جاهز" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-primary lg:text-3xl">{stat.value}</div>
                <div className="mt-1 text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="mt-10 flex items-center justify-center gap-3 flex-wrap">
            {["Arduino", "ESP32", "STM32", "Raspberry Pi Pico", "Teensy"].map((board) => (
              <div
                key={board}
                className="flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-1.5 shadow-sm"
              >
                <Cpu className="h-3.5 w-3.5 text-primary" />
                <span className="text-xs font-medium text-foreground">{board}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
