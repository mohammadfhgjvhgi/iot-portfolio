"use client"

import { useState } from "react"
import { Search, Gauge, Zap, Thermometer, Eye, Wind, Droplets, Radio, Move, Speaker, Monitor } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

const sensors = [
  // حرارة ورطوبة
  {
    name: "DHT11",
    category: "حرارة ورطوبة",
    description: "حساس رقمي اقتصادي لقياس الحرارة (0-50 درجة) والرطوبة. دقة الحرارة ±2 درجة.",
    voltage: "3.3V - 5V",
    output: "رقمي (سلك واحد)",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "المشاريع التعليمية ومحطات الطقس البسيطة",
    tip: "أضف مقاومة Pull-up 10K بين VCC و DATA.",
  },
  {
    name: "DHT22 (AM2302)",
    category: "حرارة ورطوبة",
    description: "حساس أدق من DHT11، يقيس الحرارة (-40 إلى 80 درجة) والرطوبة بدقة ±0.5 درجة.",
    voltage: "3.3V - 5V",
    output: "رقمي (سلك واحد)",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "محطات الطقس المتقدمة والبيوت الزراعية",
    tip: "قراءة واحدة كل ثانيتين كحد أقصى.",
  },
  {
    name: "BME280",
    category: "حرارة ورطوبة",
    description: "حساس متكامل يقيس الحرارة والرطوبة والضغط الجوي عبر I2C. دقة عالية جداً.",
    voltage: "3.3V",
    output: "I2C / SPI",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "محطات الطقس الاحترافية، قياس الارتفاع، التنبؤ بالطقس",
    tip: "العنوان الافتراضي 0x76 أو 0x77.",
  },
  {
    name: "DS18B20",
    category: "حرارة ورطوبة",
    description: "حساس حرارة رقمي مقاوم للماء. يمكن توصيل عدة حساسات على سلك واحد.",
    voltage: "3.0V - 5.5V",
    output: "رقمي (OneWire)",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "قياس حرارة الماء، أحواض السمك، الأنابيب",
    tip: "كل حساس له عنوان فريد ويمكن ربط 100+ على نفس السلك.",
  },
  // مسافة
  {
    name: "HC-SR04",
    category: "مسافة",
    description: "حساس أمواج فوق صوتية يقيس المسافة من 2 سم إلى 400 سم بدقة 3 مم.",
    voltage: "5V",
    output: "رقمي (Trigger/Echo)",
    compatibility: ["Arduino", "ESP32"],
    usage: "روبوتات تجنب العوائق، قياس مستوى المياه، أنظمة الركن",
    tip: "على ESP32 استخدم محول مستوى لأن Echo يعطي 5V.",
  },
  {
    name: "VL53L0X",
    category: "مسافة",
    description: "حساس ليزر (ToF) يقيس المسافة حتى 2 متر بدقة عالية عبر I2C.",
    voltage: "3.3V - 5V",
    output: "I2C",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "الروبوتات الدقيقة، كشف القرب، الخرائط ثلاثية الأبعاد",
    tip: "أسرع وأدق من HC-SR04 لكن مدى أقصر.",
  },
  {
    name: "حساس IR (Sharp GP2Y0A21)",
    category: "مسافة",
    description: "حساس مسافة بالأشعة تحت الحمراء يعمل من 10 إلى 80 سم.",
    voltage: "5V",
    output: "تناظري",
    compatibility: ["Arduino", "ESP32"],
    usage: "متتبع الخط، تجنب العوائق القريبة، عداد الأشخاص",
    tip: "القراءة غير خطية - استخدم معادلة التحويل من datasheet.",
  },
  // غاز ودخان
  {
    name: "MQ-2",
    category: "غاز ودخان",
    description: "حساس للكشف عن الغازات القابلة للاشتعال (LPG, بروبان, ميثان) والدخان.",
    voltage: "5V",
    output: "تناظري + رقمي",
    compatibility: ["Arduino", "ESP32"],
    usage: "أنظمة إنذار الحريق، كشف تسرب الغاز",
    tip: "يحتاج تسخين 24 ساعة أول مرة لقراءات دقيقة.",
  },
  {
    name: "MQ-135",
    category: "غاز ودخان",
    description: "حساس لقياس جودة الهواء والكشف عن NH3, NOx, CO2, الكحول والبنزين.",
    voltage: "5V",
    output: "تناظري + رقمي",
    compatibility: ["Arduino", "ESP32"],
    usage: "مراقبة جودة الهواء الداخلي، الفصول الدراسية الذكية",
    tip: "يحتاج معايرة (Calibration) للقراءات الدقيقة بالـ ppm.",
  },
  // حركة
  {
    name: "PIR (HC-SR501)",
    category: "حركة",
    description: "حساس كشف الحركة بالأشعة تحت الحمراء السلبية. يكشف حركة الأجسام الحية.",
    voltage: "5V - 20V",
    output: "رقمي",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "أنظمة الأمان، الإضاءة التلقائية، عداد الأشخاص",
    tip: "الحساسية ووقت التأخير قابلان للتعديل من المقاومات المتغيرة.",
  },
  {
    name: "MPU6050",
    category: "حركة",
    description: "حساس 6 محاور يجمع جيروسكوب (قياس الدوران) ومقياس تسارع (قياس الميل).",
    voltage: "3.3V - 5V",
    output: "I2C",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "الروبوتات المتوازنة، تتبع الحركة، الطائرات بدون طيار",
    tip: "استخدم مرشح كالمان أو مرشح تكاملي لقراءات مستقرة.",
  },
  {
    name: "ADXL345",
    category: "حركة",
    description: "مقياس تسارع 3 محاور رقمي عالي الدقة. يكشف السقوط الحر والنقر.",
    voltage: "2.0V - 3.6V",
    output: "I2C / SPI",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "كشف الاهتزازات، أجهزة قابلة للارتداء، قياس الميل",
    tip: "يدعم أوضاع توفير الطاقة المتعددة.",
  },
  // إضاءة
  {
    name: "LDR (مقاومة ضوئية)",
    category: "إضاءة",
    description: "مقاومة تتغير قيمتها حسب شدة الضوء. قيمة عالية في الظلام ومنخفضة في الضوء.",
    voltage: "3.3V - 5V",
    output: "تناظري",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "الإضاءة التلقائية، متتبعات الطاقة الشمسية",
    tip: "استخدمه في دائرة قسم جهد مع مقاومة 10K.",
  },
  {
    name: "BH1750",
    category: "إضاءة",
    description: "حساس إضاءة رقمي يقيس شدة الضوء بوحدة Lux عبر I2C. دقة عالية.",
    voltage: "3.3V - 5V",
    output: "I2C",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "التحكم التلقائي بالإضاءة، محطات الطقس، الزراعة الذكية",
    tip: "لا يحتاج معايرة - يعطي قيمة Lux مباشرة.",
  },
  // رطوبة تربة
  {
    name: "Soil Moisture Sensor",
    category: "رطوبة تربة",
    description: "حساس قياس رطوبة التربة لمعرفة حاجة النبات للماء.",
    voltage: "3.3V - 5V",
    output: "تناظري + رقمي",
    compatibility: ["Arduino", "ESP32"],
    usage: "أنظمة الري الذكي، الزراعة المنزلية الذكية",
    tip: "الحساس المقاوم يتآكل بسرعة - استخدم النوع السعوي (Capacitive) للمشاريع الدائمة.",
  },
  // تعريف
  {
    name: "RFID RC522",
    category: "تعريف",
    description: "قارئ بطاقات RFID يعمل بتردد 13.56 MHz. يقرأ ويكتب على البطاقات.",
    voltage: "3.3V",
    output: "SPI",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "أنظمة الدخول، الحضور والغياب، القفل الإلكتروني",
    tip: "يعمل على 3.3V فقط! لا توصله بـ 5V.",
  },
  // شاشات
  {
    name: "شاشة LCD 16x2 (I2C)",
    category: "شاشات",
    description: "شاشة كريستال سائل تعرض 16 حرفاً في سطرين. محول I2C يقلل الأسلاك لـ 4 فقط.",
    voltage: "5V",
    output: "I2C",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "عرض قراءات الحساسات، القوائم، الرسائل",
    tip: "العنوان 0x27 أو 0x3F. استخدم I2C Scanner لمعرفته.",
  },
  {
    name: "شاشة OLED SSD1306 (0.96\")",
    category: "شاشات",
    description: "شاشة OLED صغيرة عالية التباين 128x64 بكسل. لا تحتاج إضاءة خلفية.",
    voltage: "3.3V - 5V",
    output: "I2C / SPI",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "عرض الرسومات، القوائم التفاعلية، لوحات التحكم المصغرة",
    tip: "استخدم مكتبة Adafruit SSD1306 أو U8g2 للرسومات المتقدمة.",
  },
  // محركات ومشغلات
  {
    name: "Servo Motor SG90",
    category: "محركات ومشغلات",
    description: "محرك سيرفو صغير يتحرك لزاوية محددة (0-180 درجة). عزم 1.8 كجم/سم.",
    voltage: "4.8V - 6V",
    output: "PWM",
    compatibility: ["Arduino", "ESP32"],
    usage: "الروبوتات، أذرع التحكم، فتح/إغلاق الأبواب",
    tip: "لا تشغل أكثر من 2 سيرفو من طاقة Arduino مباشرة.",
  },
  {
    name: "L298N Motor Driver",
    category: "محركات ومشغلات",
    description: "لوحة تحكم بمحركين DC بقوة حتى 2A لكل محرك. تتحكم بالسرعة والاتجاه.",
    voltage: "5V - 35V",
    output: "رقمي + PWM",
    compatibility: ["Arduino", "ESP32"],
    usage: "سيارات الروبوت، الأنظمة الميكانيكية المتحركة",
    tip: "أزل jumper الـ 5V إذا كنت تستخدم جهد أعلى من 12V.",
  },
  {
    name: "وحدة ريلاي (Relay Module)",
    category: "محركات ومشغلات",
    description: "مفتاح كهربائي يتحكم بالأجهزة التي تعمل على جهد عالي (220V) من Arduino.",
    voltage: "5V (تحكم) / 250V AC (حمل)",
    output: "رقمي",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "التحكم بالأجهزة الكهربائية، المنزل الذكي",
    tip: "استخدم ريلاي Optocoupler لعزل أفضل. احذر من الجهد العالي!",
  },
  // صوت
  {
    name: "Buzzer (الصافرة)",
    category: "صوت",
    description: "جهاز إصدار أصوات. Active Buzzer يصدر صوتاً ثابتاً، Passive يمكن عزف نغمات.",
    voltage: "3.3V - 5V",
    output: "رقمي / PWM",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "التنبيهات الصوتية، الألعاب، عزف الموسيقى البسيطة",
    tip: "Passive Buzzer يحتاج PWM (tone()) لإصدار ترددات مختلفة.",
  },
  // اتصال
  {
    name: "وحدة بلوتوث HC-05/HC-06",
    category: "اتصال",
    description: "وحدة بلوتوث كلاسيكي للاتصال اللاسلكي Serial. HC-05 ماستر/سليف، HC-06 سليف فقط.",
    voltage: "3.3V (Logic) / 5V (VCC)",
    output: "UART (Serial)",
    compatibility: ["Arduino"],
    usage: "التحكم من الهاتف، نقل البيانات لاسلكياً",
    tip: "سرعة الاتصال الافتراضية 9600 baud. استخدم AT Commands للإعدادات.",
  },
  {
    name: "وحدة GPS NEO-6M",
    category: "اتصال",
    description: "وحدة تحديد موقع GPS تعطي الإحداثيات والارتفاع والسرعة والوقت.",
    voltage: "3.3V - 5V",
    output: "UART (Serial)",
    compatibility: ["Arduino", "ESP32", "Raspberry Pi"],
    usage: "تتبع المركبات، الخرائط، تسجيل المسارات",
    tip: "يحتاج سماء مفتوحة لالتقاط الأقمار. أول اتصال قد يأخذ دقائق.",
  },
]

const categories = ["الكل", ...Array.from(new Set(sensors.map((s) => s.category)))]

export default function SensorsPage() {
  const [search, setSearch] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("الكل")

  const filtered = sensors.filter((sensor) => {
    const matchesSearch = sensor.name.toLowerCase().includes(search.toLowerCase()) ||
      sensor.description.includes(search) ||
      sensor.usage.includes(search)
    const matchesCategory = selectedCategory === "الكل" || sensor.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">موسوعة الحساسات والقطع</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          دليل شامل للقطع الإلكترونية مع طريقة العمل ونصائح الاستخدام
        </p>
        <p className="mt-1 text-sm text-muted-foreground">{sensors.length} قطعة وحساس</p>
      </div>

      {/* Search & Filter */}
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ابحث عن حساس أو قطعة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-border bg-card pr-10 text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
                selectedCategory === cat
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((sensor) => (
          <Card key={sensor.name} className="border-border bg-card transition-all hover:border-primary/30 hover:shadow-md">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="text-xs">{sensor.category}</Badge>
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
                  <Gauge className="h-4 w-4 text-primary" />
                </div>
              </div>
              <CardTitle className="text-base text-foreground">{sensor.name}</CardTitle>
              <CardDescription className="text-sm text-muted-foreground">{sensor.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">الجهد</span>
                  <span className="text-foreground">{sensor.voltage}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">نوع الإخراج</span>
                  <span className="text-foreground">{sensor.output}</span>
                </div>
                <div className="mt-2">
                  <span className="text-xs text-muted-foreground">متوافق مع:</span>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {sensor.compatibility.map((c) => (
                      <Badge key={c} variant="outline" className="text-xs border-border text-muted-foreground">{c}</Badge>
                    ))}
                  </div>
                </div>
                <div className="mt-2 rounded-md bg-secondary p-2.5 text-xs text-muted-foreground">
                  <span className="font-medium text-foreground">الاستخدامات: </span>
                  {sensor.usage}
                </div>
                <div className="mt-1 rounded-md border border-primary/20 bg-primary/5 p-2.5 text-xs text-primary">
                  <span className="font-medium">نصيحة: </span>
                  {sensor.tip}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="mt-12 text-center">
          <p className="text-lg text-muted-foreground">لم يتم العثور على نتائج</p>
        </div>
      )}
    </div>
  )
}
