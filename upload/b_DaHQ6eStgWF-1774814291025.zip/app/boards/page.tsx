import { BoardComparison } from "@/components/board-comparison"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "دليل اللوحات | مشاريع التحكم الدقيق",
  description: "مقارنة شاملة بين لوحات Arduino و ESP32 و Raspberry Pi مع المميزات والعيوب والأفضلية",
}

export default function BoardsPage() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-12 lg:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">دليل اللوحات</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          دليل شامل لجميع عائلات لوحات التحكم الدقيق مع مميزاتها واستخداماتها لتساعدك في اختيار اللوحة المناسبة
        </p>
      </div>
      <BoardComparison />
    </div>
  )
}
