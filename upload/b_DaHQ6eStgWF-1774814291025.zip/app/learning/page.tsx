"use client"

import { useState } from "react"
import { BookOpen, Clock, Star, ChevronDown, ChevronUp, Wrench, FileText, CheckCircle2, Lock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface Lesson {
  title: string
  duration: string
  theory: string
  practical: string
  tools: string[]
  completed: boolean
}

interface Level {
  title: string
  badge: string
  color: string
  badgeBg: string
  description: string
  progress: number
  lessons: Lesson[]
}

const levels: Level[] = [
  {
    title: "المستوى الأول: الأساسيات",
    badge: "مبتدئ",
    color: "text-chart-2",
    badgeBg: "bg-chart-2/10 text-chart-2",
    description: "تعلّم المفاهيم الأساسية وابدأ مشروعك الأول من الصفر.",
    progress: 0,
    lessons: [
      {
        title: "ما هي لوحات التحكم الدقيق (Microcontrollers)؟",
        duration: "15 دقيقة",
        theory: "لوحات التحكم الدقيق هي أنظمة حاسوبية مصغرة على شريحة واحدة، مصممة لأداء مهام محددة. تختلف عن الحاسوب العادي بأنها تشغل برنامجاً واحداً في حلقة مستمرة (Loop). تحتوي على معالج، ذاكرة، ومنافذ إدخال/إخراج (GPIO) للتواصل مع الحساسات والمحركات.",
        practical: "افتح صندوق Arduino Uno وتعرف على كل جزء: منفذ USB، دبابيس الطاقة (5V, 3.3V, GND)، الدبابيس الرقمية (0-13)، والدبابيس التناظرية (A0-A5). حاول تحديد كل جزء ومعرفة وظيفته.",
        tools: ["Arduino Uno", "كابل USB"],
        completed: false,
      },
      {
        title: "تثبيت Arduino IDE وإعداد البيئة",
        duration: "20 دقيقة",
        theory: "Arduino IDE هو البرنامج الذي نستخدمه لكتابة الكود وتحميله على اللوحة. الكود يتكون من جزئين رئيسيين: دالة setup() التي تعمل مرة واحدة عند التشغيل، ودالة loop() التي تتكرر بشكل مستمر.",
        practical: "حمّل Arduino IDE من الموقع الرسمي. بعد التثبيت، وصّل Arduino Uno بالكمبيوتر عبر USB. اذهب إلى Tools > Board واختر Arduino Uno، ثم Tools > Port واختر المنفذ الصحيح. جرّب تحميل المثال الفارغ (BareMinimum).",
        tools: ["حاسوب", "Arduino IDE", "Arduino Uno", "كابل USB"],
        completed: false,
      },
      {
        title: "مشروعك الأول: إشعال LED (Blink)",
        duration: "25 دقيقة",
        theory: "الـ LED (الصمام الثنائي الباعث للضوء) له طرفان: الأنود (+) الأطول، والكاثود (-) الأقصر. يجب دائماً استخدام مقاومة (220 أوم) لحماية LED من التيار الزائد. دالة digitalWrite() ترسل HIGH (5V) أو LOW (0V) للدبوس.",
        practical: "وصّل LED مع مقاومة 220 أوم بالدبوس 13 و GND. افتح File > Examples > Basics > Blink. حمّل الكود وشاهد LED يومض! عدّل قيم delay() لتغيير سرعة الوميض. جرّب 100ms و 2000ms.",
        tools: ["Arduino Uno", "LED", "مقاومة 220 أوم", "أسلاك توصيل", "بريدبورد"],
        completed: false,
      },
      {
        title: "فهم الإشارات الرقمية والتناظرية",
        duration: "30 دقيقة",
        theory: "الإشارة الرقمية لها قيمتان فقط: HIGH (1) أو LOW (0). الإشارة التناظرية متدرجة من 0 إلى 1023 (10-بت). PWM (تعديل عرض النبضة) يحاكي إشارة تناظرية بإشارة رقمية سريعة التبديل، القيم من 0 إلى 255.",
        practical: "استخدم analogWrite() مع الدبوس 9 لتغيير سطوع LED تدريجياً. اكتب حلقة for تزيد القيمة من 0 إلى 255 ثم تنقصها. هذا يُنتج تأثير التنفس (Breathing Effect). جرّب تغيير سرعة التدرج.",
        tools: ["Arduino Uno", "LED", "مقاومة 220 أوم", "بريدبورد"],
        completed: false,
      },
      {
        title: "قراءة البيانات من الحساسات",
        duration: "30 دقيقة",
        theory: "الحساسات تحوّل القياسات الفيزيائية (حرارة، ضوء، مسافة) إلى إشارات كهربائية. دالة analogRead() تقرأ القيمة التناظرية (0-1023). يمكن استخدام Serial Monitor لعرض القيم على الشاشة عبر Serial.println().",
        practical: "وصّل مقاومة ضوئية (LDR) مع مقاومة 10K في دائرة قسم الجهد. اقرأ القيمة بـ analogRead(A0) واعرضها على Serial Monitor. غطِّ الحساس وشاهد تغير القيم. حاول تشغيل LED عندما تنخفض الإضاءة.",
        tools: ["Arduino Uno", "LDR", "مقاومة 10K", "LED", "بريدبورد"],
        completed: false,
      },
    ],
  },
  {
    title: "المستوى الثاني: التطوير والتوسع",
    badge: "متوسط",
    color: "text-chart-4",
    badgeBg: "bg-chart-4/10 text-chart-4",
    description: "تعلّم استخدام الشاشات والمحركات وبروتوكولات الاتصال.",
    progress: 0,
    lessons: [
      {
        title: "استخدام الشاشات: LCD و OLED",
        duration: "35 دقيقة",
        theory: "شاشة LCD 16x2 تعرض 16 حرفاً في سطرين. محول I2C يقلل الأسلاك من 16 إلى 4 فقط (VCC, GND, SDA, SCL). بروتوكول I2C يستخدم عنوان فريد لكل جهاز، العنوان الشائع 0x27 أو 0x3F.",
        practical: "وصّل شاشة LCD I2C: SDA بـ A4 و SCL بـ A5. ثبّت مكتبة LiquidCrystal_I2C. اكتب كود يعرض اسمك في السطر الأول ورسالة ترحيب في الثاني. جرّب تمرير النص باستخدام lcd.scrollDisplayLeft().",
        tools: ["Arduino Uno", "شاشة LCD 16x2 مع I2C", "أسلاك توصيل"],
        completed: false,
      },
      {
        title: "التحكم بالمحركات: DC و Servo",
        duration: "40 دقيقة",
        theory: "محرك DC يدور بشكل مستمر ويحتاج H-Bridge (مثل L293D) للتحكم بالاتجاه والسرعة. محرك Servo يتحرك لزاوية محددة (0-180 درجة) ويستخدم إشارة PWM. لا تسحب محركات كبيرة من Arduino مباشرة!",
        practical: "وصّل محرك Servo SG90: Signal بالدبوس 9، VCC بـ 5V، GND بـ GND. استخدم مكتبة Servo.h وأمر servo.write(angle). اكتب كود يحرك المحرك من 0 إلى 180 درجة ذهاباً وإياباً. أضف potentiometer للتحكم بالزاوية يدوياً.",
        tools: ["Arduino Uno", "Servo Motor SG90", "Potentiometer 10K", "بريدبورد"],
        completed: false,
      },
      {
        title: "بروتوكولات الاتصال: I2C و SPI و UART",
        duration: "45 دقيقة",
        theory: "UART (Serial): أبسط البروتوكولات، يستخدم سلكين (TX/RX)، سرعة 9600-115200 baud. I2C: سلكين (SDA/SCL) مع إمكانية ربط 127 جهاز بنفس الخط. SPI: أسرع البروتوكولات لكن يحتاج 4 أسلاك (MOSI, MISO, SCK, CS).",
        practical: "وصّل حساس BME280 عبر I2C (عنوان 0x76). استخدم I2C Scanner لاكتشاف العنوان. ثبّت مكتبة Adafruit BME280 واقرأ الحرارة والرطوبة والضغط. اعرض القيم على Serial Monitor وعلى شاشة LCD.",
        tools: ["Arduino Uno", "BME280", "شاشة LCD I2C", "بريدبورد"],
        completed: false,
      },
      {
        title: "مقدمة في ESP32 وإنترنت الأشياء",
        duration: "40 دقيقة",
        theory: "ESP32 يحتوي على WiFi وبلوتوث مدمج مع معالج ثنائي النواة بسرعة 240 MHz. يعمل على جهد 3.3V (انتبه: لا توصل 5V للدبابيس!). يمكن برمجته بـ Arduino IDE أو MicroPython. يدعم Deep Sleep لتوفير الطاقة.",
        practical: "أضف دعم ESP32 في Arduino IDE عبر Board Manager. وصّل ESP32 واختر اللوحة الصحيحة. اكتب كود للاتصال بشبكة WiFi باستخدام WiFi.h. اطبع عنوان IP على Serial Monitor. جرّب عمل Web Server بسيط يعرض صفحة HTML.",
        tools: ["ESP32 DevKit", "كابل USB-C", "حاسوب مع Arduino IDE"],
        completed: false,
      },
      {
        title: "بناء خادم ويب بسيط بـ ESP32",
        duration: "50 دقيقة",
        theory: "ESP32 يمكنه العمل كخادم ويب HTTP. يستقبل طلبات من المتصفح ويرد بصفحات HTML. يمكن التحكم بالدبابيس من المتصفح عبر مسارات URL مختلفة. AsyncWebServer أفضل من WebServer العادي للاستقرار.",
        practical: "أنشئ مشروع ESP32 Web Server يعرض قراءات حساس DHT11 على صفحة ويب. أضف أزراراً للتحكم بـ LED من المتصفح. استخدم CSS لتجميل الصفحة. اختبر الوصول من الهاتف والحاسوب عبر نفس الشبكة.",
        tools: ["ESP32 DevKit", "DHT11", "LED", "مقاومة", "بريدبورد"],
        completed: false,
      },
    ],
  },
  {
    title: "المستوى الثالث: الاحتراف والمشاريع المتقدمة",
    badge: "متقدم",
    color: "text-chart-5",
    badgeBg: "bg-chart-5/10 text-chart-5",
    description: "انتقل للمشاريع المتكاملة مع الذكاء الاصطناعي وإنترنت الأشياء.",
    progress: 0,
    lessons: [
      {
        title: "نظام MQTT لإنترنت الأشياء",
        duration: "50 دقيقة",
        theory: "MQTT بروتوكول خفيف للتواصل بين الأجهزة عبر الإنترنت. يعتمد على نموذج Publisher/Subscriber مع وسيط (Broker). الجهاز ينشر بيانات على Topic معين، وأي جهاز مشترك بنفس الـ Topic يستقبلها. مناسب جداً لأجهزة IoT محدودة الموارد.",
        practical: "ثبّت مكتبة PubSubClient على ESP32. استخدم broker مجاني مثل test.mosquitto.org. اكتب كود لنشر قراءات حساس الحرارة كل 10 ثوانٍ على topic خاص. استخدم MQTT Explorer على الحاسوب لمراقبة البيانات. أضف التحكم عن بعد بـ LED عبر topic آخر.",
        tools: ["ESP32 DevKit", "DHT11", "LED", "اتصال إنترنت"],
        completed: false,
      },
      {
        title: "الذكاء الاصطناعي على ESP32-S3 (Edge AI)",
        duration: "60 دقيقة",
        theory: "Edge AI يعني تشغيل نماذج الذكاء الاصطناعي مباشرة على الجهاز بدون إنترنت. ESP32-S3 يدعم تشغيل نماذج TFLite Micro. يمكن تدريب نموذج بسيط على الحاسوب ثم نقله للجهاز. التطبيقات تشمل: التعرف على الأصوات، تصنيف الصور، الكشف عن الحركات.",
        practical: "استخدم Edge Impulse لإنشاء مشروع تعرف على الأصوات. سجّل عينات صوتية (مثل كلمة 'افتح' و 'أغلق'). درّب النموذج وصدّره لـ Arduino Library. حمّله على ESP32-S3 واختبر التعرف الصوتي في الوقت الحقيقي.",
        tools: ["ESP32-S3", "ميكروفون I2S", "حساب Edge Impulse"],
        completed: false,
      },
      {
        title: "نظام الطاقة الشمسية والبطاريات",
        duration: "45 دقيقة",
        theory: "المشاريع الخارجية تحتاج مصدر طاقة مستقل. لوح شمسي 6V مع وحدة شحن TP4056 وبطارية Li-ion 18650 حل مثالي. ESP32 Deep Sleep يستهلك ~10uA فقط. يمكن تشغيل المحطة لأشهر بشحنة واحدة مع إيقاظ دوري كل ساعة.",
        practical: "صمم محطة طقس تعمل بالطاقة الشمسية. وصّل لوح شمسي مع TP4056 وبطارية 18650. برمج ESP32 للإيقاظ كل ساعة، قراءة الحساسات، إرسال البيانات عبر WiFi، ثم العودة لـ Deep Sleep. قس استهلاك الطاقة الفعلي.",
        tools: ["ESP32", "لوح شمسي 6V", "TP4056", "بطارية 18650", "BME280"],
        completed: false,
      },
      {
        title: "مشروع متكامل: نظام منزل ذكي",
        duration: "90 دقيقة",
        theory: "نظام المنزل الذكي يجمع عدة حساسات ومشغلات تتواصل مع بعضها. يمكن استخدام MQTT كبروتوكول اتصال مركزي. لوحة تحكم ويب (Dashboard) تعرض البيانات وتسمح بالتحكم. يمكن إضافة تطبيق Telegram للإشعارات.",
        practical: "ابنِ نظام يحتوي على: (1) حساس حرارة ورطوبة مع عرض على شاشة OLED (2) ريلاي للتحكم بمروحة عند ارتفاع الحرارة (3) حساس حركة PIR للإنارة التلقائية (4) لوحة تحكم ويب للمراقبة والتحكم عن بعد (5) إشعارات تيليجرام.",
        tools: ["ESP32", "DHT22", "شاشة OLED", "ريلاي", "PIR", "LED", "بريدبورد"],
        completed: false,
      },
    ],
  },
]

export default function LearningPage() {
  const [expandedLesson, setExpandedLesson] = useState<string | null>(null)
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set())

  function toggleLesson(title: string) {
    setExpandedLesson(expandedLesson === title ? null : title)
  }

  function toggleComplete(title: string, e: React.MouseEvent) {
    e.stopPropagation()
    setCompletedLessons(prev => {
      const next = new Set(prev)
      if (next.has(title)) next.delete(title)
      else next.add(title)
      return next
    })
  }

  function getLevelProgress(level: Level) {
    const completed = level.lessons.filter(l => completedLessons.has(l.title)).length
    return Math.round((completed / level.lessons.length) * 100)
  }

  function getTotalProgress() {
    const allLessons = levels.flatMap(l => l.lessons)
    const completed = allLessons.filter(l => completedLessons.has(l.title)).length
    return Math.round((completed / allLessons.length) * 100)
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">المسار التعليمي</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          من الصفر حتى الاحتراف - شرح نظري وعملي خطوة بخطوة
        </p>
      </div>

      {/* Overall progress */}
      <Card className="mb-8 border-border bg-card">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">التقدم الإجمالي</span>
            <span className="text-sm font-bold text-primary">{getTotalProgress()}%</span>
          </div>
          <Progress value={getTotalProgress()} className="h-3" />
          <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
            <span>{completedLessons.size} من {levels.flatMap(l => l.lessons).length} درس مكتمل</span>
            <span>{levels.length} مستويات</span>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-8">
        {levels.map((level, levelIndex) => {
          const levelProgress = getLevelProgress(level)
          return (
            <Card key={level.title} className="border-border bg-card overflow-hidden">
              <CardHeader className="border-b border-border bg-secondary/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg text-foreground">{level.title}</CardTitle>
                      <CardDescription>{level.description}</CardDescription>
                    </div>
                  </div>
                  <Badge className={level.badgeBg}>{level.badge}</Badge>
                </div>
                <div className="mt-3">
                  <div className="mb-1.5 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">التقدم</span>
                    <span className="font-medium text-foreground">{levelProgress}%</span>
                  </div>
                  <Progress value={levelProgress} className="h-2" />
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <ul className="divide-y divide-border">
                  {level.lessons.map((lesson, i) => {
                    const isExpanded = expandedLesson === lesson.title
                    const isCompleted = completedLessons.has(lesson.title)
                    return (
                      <li key={lesson.title}>
                        <button
                          className={`flex w-full items-center justify-between px-5 py-4 text-start transition-colors hover:bg-secondary/50 ${isCompleted ? "bg-primary/3" : ""}`}
                          onClick={() => toggleLesson(lesson.title)}
                        >
                          <div className="flex items-center gap-3">
                            <button
                              onClick={(e) => toggleComplete(lesson.title, e)}
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 transition-colors ${
                                isCompleted
                                  ? "border-primary bg-primary text-primary-foreground"
                                  : "border-border text-muted-foreground hover:border-primary"
                              }`}
                              aria-label={isCompleted ? "تم الإكمال" : "وضع علامة مكتمل"}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="h-4 w-4" />
                              ) : (
                                <span className="text-xs font-semibold">{i + 1}</span>
                              )}
                            </button>
                            <div>
                              <span className={`text-sm font-medium ${isCompleted ? "text-primary" : "text-foreground"}`}>
                                {lesson.title}
                              </span>
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <Clock className="h-3 w-3" />
                                <span>{lesson.duration}</span>
                              </div>
                            </div>
                          </div>
                          {isExpanded ? (
                            <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />
                          )}
                        </button>

                        {isExpanded && (
                          <div className="border-t border-border bg-secondary/20 px-5 py-5">
                            {/* Theory */}
                            <div className="mb-4">
                              <div className="mb-2 flex items-center gap-2">
                                <FileText className="h-4 w-4 text-primary" />
                                <h4 className="text-sm font-semibold text-foreground">الشرح النظري</h4>
                              </div>
                              <p className="text-sm leading-relaxed text-muted-foreground">{lesson.theory}</p>
                            </div>

                            {/* Practical */}
                            <div className="mb-4">
                              <div className="mb-2 flex items-center gap-2">
                                <Wrench className="h-4 w-4 text-chart-4" />
                                <h4 className="text-sm font-semibold text-foreground">التطبيق العملي</h4>
                              </div>
                              <p className="text-sm leading-relaxed text-muted-foreground">{lesson.practical}</p>
                            </div>

                            {/* Tools needed */}
                            <div>
                              <h4 className="mb-2 text-xs font-semibold text-muted-foreground">الأدوات المطلوبة:</h4>
                              <div className="flex flex-wrap gap-1.5">
                                {lesson.tools.map((tool) => (
                                  <Badge key={tool} variant="secondary" className="text-xs">{tool}</Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                      </li>
                    )
                  })}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
