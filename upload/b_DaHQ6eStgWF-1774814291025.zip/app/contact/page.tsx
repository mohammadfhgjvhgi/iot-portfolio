"use client"

import { useState } from "react"
import { Send, Mail, MessageCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">تواصل معنا</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          لديك سؤال أو اقتراح؟ لا تتردد في التواصل معنا
        </p>
      </div>

      {/* Contact methods */}
      <div className="mb-8 grid gap-4 sm:grid-cols-2">
        <a
          href="https://t.me/arduino_projects_group"
          target="_blank"
          rel="noopener noreferrer"
          className="group"
        >
          <Card className="h-full border-border bg-card transition-all hover:border-primary/40 hover:shadow-md">
            <CardContent className="flex items-center gap-4 pt-6">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden="true">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-semibold text-foreground">مجموعة تيليجرام</h3>
                <p className="text-sm text-muted-foreground">انضم إلى مجموعتنا على تيليجرام</p>
              </div>
            </CardContent>
          </Card>
        </a>

        <a
          href="https://facebook.com/groups/arduino_projects"
          target="_blank"
          rel="noopener noreferrer"
          className="group"
        >
          <Card className="h-full border-border bg-card transition-all hover:border-primary/40 hover:shadow-md">
            <CardContent className="flex items-center gap-4 pt-6">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden="true">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-semibold text-foreground">مجموعة فيسبوك</h3>
                <p className="text-sm text-muted-foreground">تابعنا على صفحة فيسبوك</p>
              </div>
            </CardContent>
          </Card>
        </a>
      </div>

      {/* Contact form */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Mail className="h-5 w-5 text-primary" />
            أرسل لنا رسالة
          </CardTitle>
          <CardDescription>سنرد عليك في أقرب وقت ممكن</CardDescription>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <div className="flex flex-col items-center py-8 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Send className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">شكراً لتواصلك معنا</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                تم استلام رسالتك بنجاح. سنرد عليك قريباً عبر البريد الإلكتروني.
              </p>
              <Button className="mt-6" onClick={() => setSubmitted(false)}>
                إرسال رسالة أخرى
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="flex flex-col gap-2">
                  <Label htmlFor="name" className="text-foreground">الاسم</Label>
                  <Input
                    id="name"
                    placeholder="أدخل اسمك"
                    required
                    className="border-border bg-secondary text-foreground placeholder:text-muted-foreground"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label htmlFor="email" className="text-foreground">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="example@email.com"
                    required
                    dir="ltr"
                    className="border-border bg-secondary text-foreground placeholder:text-muted-foreground"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="subject" className="text-foreground">الموضوع</Label>
                <Input
                  id="subject"
                  placeholder="موضوع الرسالة"
                  required
                  className="border-border bg-secondary text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="message" className="text-foreground">الرسالة</Label>
                <Textarea
                  id="message"
                  placeholder="اكتب رسالتك هنا..."
                  required
                  className="min-h-[120px] resize-none border-border bg-secondary text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <Button type="submit" className="self-start">
                <Send className="ml-2 h-4 w-4" />
                إرسال الرسالة
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
