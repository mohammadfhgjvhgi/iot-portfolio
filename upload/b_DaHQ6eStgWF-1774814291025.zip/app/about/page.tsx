import { Cpu, Target, Users, BookOpen, Lightbulb, GraduationCap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "من نحن | مشاريع التحكم الدقيق",
  description: "تعرف على موقع مشاريع لوحات التحكم الدقيق الطلابية وأهدافنا ورسالتنا",
}

const goals = [
  {
    icon: GraduationCap,
    title: "تعليم مبسّط",
    description: "نقدم محتوى تعليمي باللغة العربية يبدأ من الصفر ويتدرج حتى الاحتراف في الأنظمة المدمجة.",
  },
  {
    icon: Lightbulb,
    title: "تحفيز الابتكار",
    description: "نساعد الطلاب على تحويل أفكارهم إلى مشاريع حقيقية باستخدام لوحات التحكم الدقيق والذكاء الاصطناعي.",
  },
  {
    icon: Users,
    title: "بناء مجتمع",
    description: "نوفر منصة للطلاب لتبادل الخبرات والمشاريع والأسئلة مع بعضهم البعض.",
  },
  {
    icon: BookOpen,
    title: "مرجع شامل",
    description: "نجمع كل ما يحتاجه الطالب من معلومات عن اللوحات والحساسات والتوصيلات والبرمجة في مكان واحد.",
  },
]

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">من نحن</h1>
        <p className="mt-3 text-lg leading-relaxed text-muted-foreground">
          تعرف على الموقع وأهدافنا ورسالتنا التعليمية
        </p>
      </div>

      {/* About the site */}
      <Card className="mb-8 border-border bg-card">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Cpu className="h-5 w-5 text-primary" />
            </div>
            <CardTitle className="text-xl text-foreground">عن الموقع</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed text-muted-foreground">
            موقع <span className="font-semibold text-foreground">مشاريع لوحات التحكم الدقيق الطلابية</span> هو
            منصة تعليمية وتفاعلية شاملة تهدف إلى تعليم الطلاب العرب أساسيات الأنظمة المدمجة
            (Embedded Systems) والذكاء الاصطناعي من خلال مشاريع عملية تستخدم لوحات مثل Arduino و ESP32
            و Raspberry Pi وغيرها. تم تصميم الموقع ليكون مرجعاً متكاملاً يغطي كل ما يحتاجه
            الطالب من شروحات نظرية وتطبيقات عملية وأدوات برمجية.
          </p>
        </CardContent>
      </Card>

      {/* Mission */}
      <Card className="mb-8 border-border bg-card">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Target className="h-5 w-5 text-primary" />
            </div>
            <CardTitle className="text-xl text-foreground">رسالتنا</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed text-muted-foreground">
            نؤمن بأن كل طالب يستطيع أن يبتكر ويبدع في مجال الإلكترونيات والبرمجة إذا توفرت له الأدوات
            والمصادر المناسبة باللغة العربية. رسالتنا هي تمكين الجيل القادم من المهندسين والمبتكرين العرب
            من خلال توفير محتوى تعليمي عالي الجودة، وأدوات تفاعلية تساعدهم على التعلم بسرعة وكفاءة،
            ومجتمع داعم يشجعهم على الاستمرار والتطور.
          </p>
        </CardContent>
      </Card>

      {/* Goals */}
      <div className="mb-8">
        <h2 className="mb-6 text-center text-2xl font-bold text-foreground">أهدافنا</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {goals.map((goal) => (
            <Card key={goal.title} className="border-border bg-card">
              <CardContent className="pt-6">
                <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <goal.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mb-2 text-base font-semibold text-foreground">{goal.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{goal.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Team */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="text-center text-xl text-foreground">فريق العمل</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 sm:grid-cols-2">
            <div className="flex flex-col items-center rounded-lg border border-border bg-secondary/50 p-6 text-center">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-2xl font-bold text-primary">
                عم
              </div>
              <h3 className="text-base font-bold text-foreground">عمار مشارقة</h3>
              <p className="mt-1 text-sm text-muted-foreground">مؤسس ومطور الموقع</p>
            </div>
            <div className="flex flex-col items-center rounded-lg border border-border bg-secondary/50 p-6 text-center">
              <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-2xl font-bold text-primary">
                مع
              </div>
              <h3 className="text-base font-bold text-foreground">محمد عقيلي</h3>
              <p className="mt-1 text-sm text-muted-foreground">مؤسس ومطور الموقع</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
