import { MonitorDown, Download, Settings, Play, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "بيئات البرمجة | مشاريع التحكم الدقيق",
  description: "شرح تحميل وتشغيل Arduino IDE و VS Code و MicroPython خطوة بخطوة",
}

const environments = [
  {
    name: "Arduino IDE",
    version: "2.x",
    icon: "A",
    description: "البيئة الرسمية لبرمجة لوحات Arduino. سهلة الاستخدام ومناسبة للمبتدئين.",
    downloadUrl: "https://www.arduino.cc/en/software",
    compatibility: ["Arduino", "ESP32", "ESP8266"],
    steps: [
      "حمّل Arduino IDE من الموقع الرسمي arduino.cc/en/software.",
      "ثبّت البرنامج واتبع خطوات المعالج.",
      "وصّل لوحة Arduino بكابل USB.",
      "من قائمة Tools > Board اختر نوع لوحتك.",
      "من قائمة Tools > Port اختر المنفذ الصحيح.",
      "اكتب الكود واضغط Upload (السهم الأيمن).",
    ],
    tips: [
      "استخدم Library Manager لتثبيت المكتبات بسهولة.",
      "Serial Monitor (Ctrl+Shift+M) لمراقبة البيانات.",
      "لبرمجة ESP32: أضف رابط Board Manager من إعدادات اللوحات.",
    ],
  },
  {
    name: "VS Code + PlatformIO",
    version: "متقدم",
    icon: "VS",
    description: "بيئة تطوير متقدمة مع دعم IntelliSense والإكمال التلقائي وإدارة المشاريع.",
    downloadUrl: "https://code.visualstudio.com",
    compatibility: ["Arduino", "ESP32", "ESP8266", "STM32"],
    steps: [
      "حمّل VS Code من code.visualstudio.com.",
      "ثبّت البرنامج وافتحه.",
      "اذهب لقسم Extensions (Ctrl+Shift+X).",
      "ابحث عن PlatformIO IDE وثبّته.",
      "أعد تشغيل VS Code بعد التثبيت.",
      "أنشئ مشروع جديد من PlatformIO Home.",
      "اختر اللوحة والإطار البرمجي (Arduino Framework).",
    ],
    tips: [
      "PlatformIO يدير المكتبات تلقائيًا لكل مشروع.",
      "يدعم IntelliSense لإكمال الكود تلقائيًا.",
      "يمكن فتح مشاريع Arduino IDE الحالية بسهولة.",
    ],
  },
  {
    name: "MicroPython (Thonny)",
    version: "Python",
    icon: "MP",
    description: "برمجة المتحكمات بلغة Python. مثالي لمن يعرف Python ويريد برمجة ESP32.",
    downloadUrl: "https://thonny.org",
    compatibility: ["ESP32", "ESP8266", "Raspberry Pi Pico"],
    steps: [
      "حمّل Thonny IDE من thonny.org.",
      "ثبّت البرنامج وافتحه.",
      "من قائمة Tools > Options > Interpreter اختر MicroPython (ESP32).",
      "وصّل ESP32 واختر المنفذ الصحيح.",
      "ثبّت MicroPython firmware على ESP32 (من Tools > Install MicroPython).",
      "اكتب كود Python واضغط Run.",
    ],
    tips: [
      "MicroPython أبطأ من C++ ولكن أسهل في الكتابة.",
      "يدعم REPL للتجربة المباشرة على اللوحة.",
      "ملف boot.py يعمل تلقائيًا عند تشغيل اللوحة.",
    ],
  },
]

export default function EnvironmentsPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">بيئات البرمجة</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          شرح تحميل وتشغيل البرامج خطوة بخطوة
        </p>
      </div>

      <div className="flex flex-col gap-8">
        {environments.map((env) => (
          <Card key={env.name} className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-xl font-bold text-primary">
                    {env.icon}
                  </div>
                  <div>
                    <CardTitle className="text-xl text-foreground">{env.name}</CardTitle>
                    <CardDescription className="text-muted-foreground">{env.description}</CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className="border-border text-muted-foreground">{env.version}</Badge>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5">
                {env.compatibility.map((c) => (
                  <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>
                ))}
              </div>
            </CardHeader>

            <CardContent>
              {/* Steps */}
              <div className="mb-6">
                <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Download className="h-4 w-4 text-primary" />
                  خطوات التثبيت والإعداد
                </h3>
                <ol className="flex flex-col gap-2">
                  {env.steps.map((step, i) => (
                    <li key={step} className="flex items-start gap-3 rounded-lg bg-secondary px-4 py-2.5">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                        {i + 1}
                      </span>
                      <span className="text-sm text-foreground">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Tips */}
              <div className="mb-4">
                <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Settings className="h-4 w-4 text-primary" />
                  نصائح مفيدة
                </h3>
                <ul className="flex flex-col gap-1.5">
                  {env.tips.map((tip) => (
                    <li key={tip} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Play className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Download Link */}
              <Button asChild variant="outline" size="sm" className="border-border text-foreground">
                <a href={env.downloadUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="ml-1 h-4 w-4" />
                  تحميل {env.name}
                </a>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
