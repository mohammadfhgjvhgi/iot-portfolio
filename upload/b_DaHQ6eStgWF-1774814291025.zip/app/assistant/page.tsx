"use client"

import { useState } from "react"
import { Lightbulb, Cpu, ArrowLeft, Sparkles } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const readyProjects = [
  {
    title: "نظام إنذار حريق ذكي",
    board: "Arduino",
    level: "مبتدئ",
    description: "يكتشف الدخان والحرارة ويُطلق إنذارًا صوتيًا ومرئيًا.",
    components: ["Arduino Uno", "MQ-2", "DHT11", "Buzzer", "LED"],
  },
  {
    title: "محطة طقس منزلية",
    board: "ESP32",
    level: "متوسط",
    description: "تقيس درجة الحرارة والرطوبة والضغط الجوي وترسل البيانات لشاشة ويب.",
    components: ["ESP32", "BME280", "OLED Display"],
  },
  {
    title: "نظام ري ذكي",
    board: "ESP32",
    level: "متوسط",
    description: "يراقب رطوبة التربة ويتحكم بالمضخة تلقائيًا مع إشعارات تيليجرام.",
    components: ["ESP32", "Soil Moisture Sensor", "Relay", "Water Pump"],
  },
  {
    title: "روبوت متتبع للخط",
    board: "Arduino",
    level: "مبتدئ",
    description: "روبوت يتبع خطًا أسود على أرضية بيضاء باستخدام حساسات IR.",
    components: ["Arduino Uno", "IR Sensors x2", "L298N Motor Driver", "DC Motors x2"],
  },
  {
    title: "قفل باب ذكي",
    board: "Arduino",
    level: "متوسط",
    description: "نظام قفل يعمل بالأرقام السرية أو بصمة RFID.",
    components: ["Arduino Uno", "Keypad 4x4", "RFID RC522", "Servo Motor", "LCD"],
  },
  {
    title: "كاميرا مراقبة ذكية",
    board: "Raspberry Pi",
    level: "متقدم",
    description: "نظام مراقبة مع كشف الحركة وتسجيل فيديو وإشعارات.",
    components: ["Raspberry Pi 4", "Pi Camera", "PIR Sensor"],
  },
]

export default function AssistantPage() {
  const [mode, setMode] = useState<"choose" | "ready" | "generate">("choose")
  const [level, setLevel] = useState("")
  const [board, setBoard] = useState("")
  const [interest, setInterest] = useState("")
  const [generatedIdea, setGeneratedIdea] = useState<null | { title: string; description: string; components: string[] }>(null)

  function handleGenerate() {
    const ideas = [
      {
        title: "نظام مراقبة جودة الهواء",
        description: `مشروع ${level === "beginner" ? "بسيط" : "متقدم"} باستخدام ${board || "Arduino"} لقياس جودة الهواء المحيط. يقيس مستوى الغازات الضارة ودرجة الحرارة والرطوبة ويعرض النتائج على شاشة LCD${board === "ESP32" ? " مع إرسال البيانات عبر WiFi" : ""}.`,
        components: [board || "Arduino Uno", "MQ-135", "DHT22", "LCD 16x2", "Buzzer"],
      },
      {
        title: "نظام تتبع الطاقة الشمسية",
        description: `مشروع ${level === "beginner" ? "تعليمي" : "عملي"} لبناء متتبع شمسي يوجه اللوح الشمسي نحو الشمس تلقائيًا لزيادة كفاءة توليد الطاقة.`,
        components: [board || "Arduino Uno", "LDR x4", "Servo Motor x2", "Solar Panel"],
      },
    ]
    setGeneratedIdea(ideas[Math.floor(Math.random() * ideas.length)])
  }

  if (mode === "choose") {
    return (
      <div className="mx-auto max-w-4xl px-4 py-12 lg:py-16">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-bold text-foreground lg:text-4xl">مساعد المشاريع الذكي</h1>
          <p className="mt-3 text-lg text-muted-foreground">اختر طريقتك للبدء في مشروعك القادم</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card
            className="cursor-pointer border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg"
            onClick={() => setMode("ready")}
          >
            <CardHeader className="text-center">
              <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                <Cpu className="h-7 w-7 text-primary" />
              </div>
              <CardTitle className="text-foreground">مشروعات جاهزة</CardTitle>
              <CardDescription className="text-muted-foreground">
                تصفح مشاريع كاملة مع الشرح والمكونات والكود
              </CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="cursor-pointer border-border bg-card transition-all hover:border-primary/50 hover:shadow-lg"
            onClick={() => setMode("generate")}
          >
            <CardHeader className="text-center">
              <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                <Lightbulb className="h-7 w-7 text-primary" />
              </div>
              <CardTitle className="text-foreground">توليد فكرة مشروع</CardTitle>
              <CardDescription className="text-muted-foreground">
                أدخل اهتماماتك ومستواك لنقترح لك فكرة مشروع
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    )
  }

  if (mode === "ready") {
    return (
      <div className="mx-auto max-w-6xl px-4 py-12 lg:py-16">
        <div className="mb-8 flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => setMode("choose")}>
            <ArrowLeft className="ml-1 h-4 w-4" />
            رجوع
          </Button>
          <h1 className="text-2xl font-bold text-foreground">مشروعات جاهزة</h1>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {readyProjects.map((project) => (
            <Card key={project.title} className="border-border bg-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Badge variant="secondary">{project.board}</Badge>
                  <Badge variant="outline" className="text-muted-foreground border-border">{project.level}</Badge>
                </div>
                <CardTitle className="text-lg text-foreground">{project.title}</CardTitle>
                <CardDescription className="text-muted-foreground">{project.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <h4 className="mb-2 text-sm font-semibold text-foreground">المكونات المطلوبة:</h4>
                <div className="flex flex-wrap gap-1.5">
                  {project.components.map((comp) => (
                    <Badge key={comp} variant="secondary" className="text-xs">
                      {comp}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-12 lg:py-16">
      <div className="mb-8 flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => { setMode("choose"); setGeneratedIdea(null) }}>
          <ArrowLeft className="ml-1 h-4 w-4" />
          رجوع
        </Button>
        <h1 className="text-2xl font-bold text-foreground">توليد فكرة مشروع</h1>
      </div>

      <Card className="border-border bg-card">
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4">
            <div>
              <Label className="text-foreground">المستوى</Label>
              <Select value={level} onValueChange={setLevel}>
                <SelectTrigger className="mt-1.5 border-border bg-secondary text-foreground">
                  <SelectValue placeholder="اختر مستواك" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">مبتدئ</SelectItem>
                  <SelectItem value="intermediate">متوسط</SelectItem>
                  <SelectItem value="advanced">متقدم</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-foreground">اللوحة المفضلة</Label>
              <Select value={board} onValueChange={setBoard}>
                <SelectTrigger className="mt-1.5 border-border bg-secondary text-foreground">
                  <SelectValue placeholder="اختر اللوحة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Arduino">Arduino</SelectItem>
                  <SelectItem value="ESP32">ESP32</SelectItem>
                  <SelectItem value="Raspberry Pi">Raspberry Pi</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-foreground">مجال الاهتمام</Label>
              <Input
                value={interest}
                onChange={(e) => setInterest(e.target.value)}
                placeholder="مثال: زراعة، أمان، منزل ذكي..."
                className="mt-1.5 border-border bg-secondary text-foreground placeholder:text-muted-foreground"
              />
            </div>

            <Button onClick={handleGenerate} className="mt-2">
              <Sparkles className="ml-1 h-4 w-4" />
              اقترح فكرة مشروع
            </Button>
          </div>
        </CardContent>
      </Card>

      {generatedIdea && (
        <Card className="mt-6 border-primary/30 bg-primary/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg text-foreground">{generatedIdea.title}</CardTitle>
            </div>
            <CardDescription className="text-muted-foreground">{generatedIdea.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <h4 className="mb-2 text-sm font-semibold text-foreground">المكونات المقترحة:</h4>
            <div className="flex flex-wrap gap-1.5">
              {generatedIdea.components.map((comp) => (
                <Badge key={comp} variant="secondary" className="text-xs">
                  {comp}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
