import { HeroSection } from "@/components/hero-section"
import { SectionsGrid } from "@/components/sections-grid"

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <SectionsGrid />
    </>
  )
}
