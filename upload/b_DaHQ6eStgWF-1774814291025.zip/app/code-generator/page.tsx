"use client"

import { useState } from "react"
import { Code2, Copy, Check, Sparkles } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const codeTemplates: Record<string, Record<string, string>> = {
  "blink-led": {
    Arduino: `// مشروع إشعال LED - Arduino
const int LED_PIN = 13;

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);  // تشغيل LED
  delay(1000);                  // انتظار ثانية
  digitalWrite(LED_PIN, LOW);   // إطفاء LED
  delay(1000);                  // انتظار ثانية
}`,
    ESP32: `// مشروع إشعال LED - ESP32
const int LED_PIN = 2;  // LED المدمج في ESP32

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  digitalWrite(LED_PIN, HIGH);
  delay(1000);
  digitalWrite(LED_PIN, LOW);
  delay(1000);
}`,
    "Raspberry Pi": `# مشروع إشعال LED - Raspberry Pi
import RPi.GPIO as GPIO
import time

LED_PIN = 18

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN, GPIO.OUT)

try:
    while True:
        GPIO.output(LED_PIN, GPIO.HIGH)  # تشغيل
        time.sleep(1)
        GPIO.output(LED_PIN, GPIO.LOW)   # إطفاء
        time.sleep(1)
except KeyboardInterrupt:
    GPIO.cleanup()`,
  },
  "temp-sensor": {
    Arduino: `// قراءة حساس الحرارة DHT11 - Arduino
#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("خطأ في قراءة الحساس!");
    return;
  }

  Serial.print("الحرارة: ");
  Serial.print(temp);
  Serial.print(" °C | الرطوبة: ");
  Serial.print(hum);
  Serial.println(" %");

  delay(2000);
}`,
    ESP32: `// قراءة حساس الحرارة DHT22 - ESP32
#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  Serial.println("بدء قراءة الحساس...");
}

void loop() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("خطأ في قراءة الحساس!");
    return;
  }

  Serial.printf("الحرارة: %.1f °C | الرطوبة: %.1f %%\\n", temp, hum);
  delay(2000);
}`,
  },
  "servo-motor": {
    Arduino: `// التحكم بمحرك Servo - Arduino
#include <Servo.h>

Servo myServo;
const int SERVO_PIN = 9;

void setup() {
  myServo.attach(SERVO_PIN);
  Serial.begin(9600);
}

void loop() {
  // حركة من 0 إلى 180 درجة
  for (int angle = 0; angle <= 180; angle += 10) {
    myServo.write(angle);
    Serial.print("الزاوية: ");
    Serial.println(angle);
    delay(500);
  }

  // حركة عكسية من 180 إلى 0
  for (int angle = 180; angle >= 0; angle -= 10) {
    myServo.write(angle);
    Serial.print("الزاوية: ");
    Serial.println(angle);
    delay(500);
  }
}`,
  },
  "ultrasonic": {
    Arduino: `// قياس المسافة بحساس HC-SR04 - Arduino
const int TRIG_PIN = 9;
const int ECHO_PIN = 10;

void setup() {
  Serial.begin(9600);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

void loop() {
  // إرسال نبضة
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // قراءة المدة
  long duration = pulseIn(ECHO_PIN, HIGH);

  // حساب المسافة بالسنتيمتر
  float distance = duration * 0.034 / 2;

  Serial.print("المسافة: ");
  Serial.print(distance);
  Serial.println(" سم");

  delay(500);
}`,
    ESP32: `// قياس المسافة بحساس HC-SR04 - ESP32
const int TRIG_PIN = 5;
const int ECHO_PIN = 18;

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH);
  float distance = duration * 0.034 / 2;

  Serial.printf("المسافة: %.1f سم\\n", distance);
  delay(500);
}`,
  },
}

const projectDescriptions: Record<string, string> = {
  "blink-led": "إشعال وإطفاء LED",
  "temp-sensor": "قراءة حساس الحرارة والرطوبة",
  "servo-motor": "التحكم بمحرك Servo",
  "ultrasonic": "قياس المسافة بالموجات فوق الصوتية",
}

export default function CodeGeneratorPage() {
  const [selectedProject, setSelectedProject] = useState("")
  const [selectedBoard, setSelectedBoard] = useState("")
  const [customDescription, setCustomDescription] = useState("")
  const [generatedCode, setGeneratedCode] = useState("")
  const [copied, setCopied] = useState(false)

  function handleGenerate() {
    if (selectedProject && selectedBoard) {
      const templates = codeTemplates[selectedProject]
      if (templates && templates[selectedBoard]) {
        setGeneratedCode(templates[selectedBoard])
      } else {
        setGeneratedCode(`// لا يتوفر كود جاهز لهذه اللوحة حاليًا\n// جرّب لوحة أخرى أو تواصل معنا عبر ملتقى المبدعين`)
      }
    }
  }

  async function handleCopy() {
    await navigator.clipboard.writeText(generatedCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">بوت البرمجة</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          اختر مشروعك واللوحة وسنوّلد لك الكود البرمجي الجاهز
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-foreground">
              <Sparkles className="h-5 w-5 text-primary" />
              اختر المشروع
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              حدد نوع المشروع واللوحة المستهدفة
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div>
                <Label className="text-foreground">نوع المشروع</Label>
                <Select value={selectedProject} onValueChange={setSelectedProject}>
                  <SelectTrigger className="mt-1.5 border-border bg-secondary text-foreground">
                    <SelectValue placeholder="اختر المشروع" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(projectDescriptions).map(([key, desc]) => (
                      <SelectItem key={key} value={key}>{desc}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-foreground">اللوحة</Label>
                <Select value={selectedBoard} onValueChange={setSelectedBoard}>
                  <SelectTrigger className="mt-1.5 border-border bg-secondary text-foreground">
                    <SelectValue placeholder="اختر اللوحة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Arduino">Arduino</SelectItem>
                    <SelectItem value="ESP32">ESP32</SelectItem>
                    <SelectItem value="Raspberry Pi">Raspberry Pi</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-foreground">وصف إضافي (اختياري)</Label>
                <Textarea
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  placeholder="أضف تفاصيل إضافية عن مشروعك..."
                  className="mt-1.5 min-h-[80px] resize-none border-border bg-secondary text-foreground placeholder:text-muted-foreground"
                />
              </div>

              <Button
                onClick={handleGenerate}
                disabled={!selectedProject || !selectedBoard}
                className="w-full"
              >
                <Code2 className="ml-1 h-4 w-4" />
                توليد الكود
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Output */}
        <Card className="border-border bg-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Code2 className="h-5 w-5 text-primary" />
                الكود البرمجي
              </CardTitle>
              {generatedCode && (
                <Button variant="ghost" size="sm" onClick={handleCopy} className="text-muted-foreground">
                  {copied ? (
                    <>
                      <Check className="ml-1 h-4 w-4 text-primary" />
                      تم النسخ
                    </>
                  ) : (
                    <>
                      <Copy className="ml-1 h-4 w-4" />
                      نسخ
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {generatedCode ? (
              <pre className="overflow-x-auto rounded-lg bg-secondary p-4 text-sm leading-relaxed text-foreground" dir="ltr">
                <code>{generatedCode}</code>
              </pre>
            ) : (
              <div className="flex h-48 items-center justify-center rounded-lg border border-dashed border-border">
                <p className="text-sm text-muted-foreground">
                  اختر المشروع واللوحة ثم اضغط توليد الكود
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
