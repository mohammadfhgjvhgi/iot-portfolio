import { Cable, AlertTriangle, CheckCircle2, Info, Zap, Shield, CircuitBoard, BookOpen } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "دليل التوصيل والإرشاد | مشاريع التحكم الدقيق",
  description: "شروحات تفصيلية لطرق الربط مع نصائح تقنية لتجنب حرق القطع",
}

const fundamentals = [
  {
    title: "فهم الجهد والتيار والمقاومة",
    content: "الجهد (V) يشبه ضغط الماء في الأنبوب، والتيار (A) يشبه كمية الماء المتدفقة، والمقاومة (R) تشبه ضيق الأنبوب. العلاقة بينهم: V = I x R (قانون أوم). Arduino يعطي 5V و ESP32 يعطي 3.3V. تجاوز الجهد المسموح يحرق القطعة.",
  },
  {
    title: "أنواع الدبابيس في Arduino",
    content: "الدبابيس الرقمية (D0-D13): ترسل أو تستقبل HIGH (5V) أو LOW (0V) فقط. الدبابيس التناظرية (A0-A5): تقرأ قيم متدرجة من 0 إلى 1023. دبابيس PWM (مميزة بـ ~): تحاكي إشارة تناظرية بقيم 0-255. دبابيس الطاقة: 5V, 3.3V, GND, Vin.",
  },
  {
    title: "البريدبورد (Breadboard)",
    content: "البريدبورد لوح تجارب بدون لحام. الصفوف الأفقية في المنتصف متصلة داخلياً (5 فتحات لكل صف). خطوط الطاقة على الأطراف (+/-) متصلة رأسياً. الفاصل في المنتصف يقطع الاتصال. استخدم أسلاك jumper للتوصيل.",
  },
  {
    title: "قراءة الألوان على المقاومات",
    content: "المقاومة لها أشرطة ملونة تدل على قيمتها. الشريط الأول = الرقم الأول، الثاني = الرقم الثاني، الثالث = المضاعف، الرابع = نسبة الخطأ. مثال: أحمر-أحمر-بني = 220 أوم. ذهبي = 5% خطأ. المقاومات الشائعة: 220, 330, 1K, 4.7K, 10K أوم.",
  },
  {
    title: "الفرق بين 3.3V و 5V",
    content: "Arduino Uno يعمل على 5V لكن ESP32 يعمل على 3.3V. لا توصل خرج 5V مباشرة بدبوس ESP32 لأنه سيحترق! الحل: استخدم محول مستوى جهد (Level Shifter) أو قسم جهد بمقاومتين. حساسات كثيرة تعمل على كلا الجهدين لكن تحقق دائماً من الـ datasheet.",
  },
  {
    title: "Pull-up و Pull-down Resistors",
    content: "عندما يكون الدبوس غير متصل بشيء يقرأ قيماً عشوائية (floating). مقاومة Pull-up (10K إلى VCC) تجعل القراءة الافتراضية HIGH. مقاومة Pull-down (10K إلى GND) تجعلها LOW. Arduino يحتوي على Pull-up داخلي يمكن تفعيله بـ INPUT_PULLUP.",
  },
]

const wiringGuides = [
  {
    title: "توصيل LED مع مقاومة",
    level: "مبتدئ",
    components: ["Arduino Uno", "LED", "مقاومة 220 أوم", "بريدبورد", "سلكين jumper"],
    steps: [
      "ضع LED على البريدبورد. حدد الطرف الطويل (أنود +) والقصير (كاثود -).",
      "وصّل مقاومة 220 أوم من الدبوس 13 على Arduino إلى صف الأنود (+).",
      "وصّل سلك من صف الكاثود (-) إلى GND على Arduino.",
      "افتح Arduino IDE > File > Examples > Basics > Blink.",
      "حمّل الكود على اللوحة وشاهد LED يومض.",
    ],
    warning: "لا توصل LED مباشرة بدون مقاومة! التيار الزائد سيحرقه فوراً. المقاومة تحدد التيار: 220 أوم مع 5V = ~15mA (آمن).",
    tip: "لمعرفة قيمة المقاومة المناسبة: R = (Vsource - Vled) / I. معظم LED يحتاج 10-20mA وجهد أمامي 2V.",
    theory: "LED يسمح بمرور التيار في اتجاه واحد فقط. عند مرور التيار يصدر ضوءاً. كل لون له جهد أمامي مختلف: أحمر 1.8V، أخضر 2V، أزرق 3V.",
  },
  {
    title: "توصيل حساس DHT11/DHT22",
    level: "مبتدئ",
    components: ["Arduino Uno", "DHT11 أو DHT22", "مقاومة 10K أوم", "بريدبورد"],
    steps: [
      "حدد أطراف الحساس (من اليسار): VCC, DATA, (فارغ), GND.",
      "وصّل VCC بـ 5V على Arduino.",
      "وصّل GND بـ GND على Arduino.",
      "وصّل DATA بالدبوس الرقمي 2.",
      "أضف مقاومة Pull-up 10K بين VCC و DATA.",
      "ثبّت مكتبة DHT من Sketch > Include Library > Manage Libraries.",
    ],
    warning: "تأكد من عدم عكس VCC و GND - سيحترق الحساس. أيضاً لا تقرأ الحساس أكثر من مرة كل ثانيتين (DHT11) أو ثانية (DHT22).",
    tip: "DHT22 أدق (±0.5 درجة) لكن DHT11 أرخص (±2 درجة) ويكفي للتعلم. مقاومة Pull-up ضرورية لاستقرار الإشارة.",
    theory: "الحساس يحتوي على عنصر حساس للرطوبة ومقاوم حراري NTC. يرسل البيانات كإشارة رقمية تسلسلية على سلك واحد. كل قراءة تتكون من 40 بت (16 رطوبة + 16 حرارة + 8 checksum).",
  },
  {
    title: "توصيل محرك Servo SG90",
    level: "متوسط",
    components: ["Arduino Uno", "Servo SG90", "أسلاك توصيل"],
    steps: [
      "حدد أسلاك المحرك: برتقالي (Signal)، أحمر (VCC)، بني (GND).",
      "وصّل السلك البرتقالي بالدبوس الرقمي 9 (PWM).",
      "وصّل السلك الأحمر بـ 5V.",
      "وصّل السلك البني بـ GND.",
      "استخدم #include <Servo.h> في الكود.",
      "أنشئ كائن Servo واستخدم servo.attach(9) ثم servo.write(angle).",
    ],
    warning: "لا تشغل أكثر من محركين SG90 من Arduino مباشرة! المحركات الكبيرة تحتاج مصدر طاقة خارجي منفصل (مع توصيل GND المشترك).",
    tip: "أضف مكثف 100uF بين VCC و GND لتثبيت الجهد ومنع ارتجاج المحرك. استخدم map() لتحويل قيم المقاومة المتغيرة إلى زوايا.",
    theory: "Servo يستقبل إشارة PWM بتردد 50Hz. عرض النبضة يحدد الزاوية: 1ms = 0 درجة، 1.5ms = 90 درجة، 2ms = 180 درجة. مكتبة Servo تتعامل مع هذا تلقائياً.",
  },
  {
    title: "توصيل شاشة LCD 16x2 عبر I2C",
    level: "متوسط",
    components: ["Arduino Uno", "LCD 16x2 مع محول I2C", "4 أسلاك"],
    steps: [
      "وصّل GND بـ GND على Arduino.",
      "وصّل VCC بـ 5V على Arduino.",
      "وصّل SDA بالدبوس A4 (على Uno/Nano) أو الدبوس المخصص.",
      "وصّل SCL بالدبوس A5 (على Uno/Nano) أو الدبوس المخصص.",
      "ثبّت مكتبة LiquidCrystal_I2C.",
      "استخدم LiquidCrystal_I2C lcd(0x27, 16, 2) لإنشاء الكائن.",
    ],
    warning: "إذا لم تظهر كتابة: (1) جرّب العنوان 0x3F بدل 0x27 (2) اضبط التباين من المقاومة المتغيرة خلف المحول (3) تأكد من التوصيلات.",
    tip: "استخدم كود I2C Scanner لاكتشاف العنوان الصحيح تلقائياً. على ESP32 دبابيس I2C مختلفة: SDA=21, SCL=22.",
    theory: "I2C بروتوكول اتصال يستخدم سلكين: SDA (بيانات) و SCL (ساعة). كل جهاز له عنوان فريد (7 بت). يمكن ربط حتى 127 جهاز على نفس الخط. السرعة الافتراضية 100 KHz.",
  },
  {
    title: "توصيل حساس المسافة HC-SR04",
    level: "متوسط",
    components: ["Arduino Uno", "HC-SR04", "بريدبورد", "4 أسلاك"],
    steps: [
      "وصّل VCC بـ 5V على Arduino.",
      "وصّل GND بـ GND على Arduino.",
      "وصّل Trigger بالدبوس الرقمي 9.",
      "وصّل Echo بالدبوس الرقمي 10.",
      "استخدم pulseIn(echoPin, HIGH) لقياس زمن الارتداد.",
      "المسافة (سم) = (الزمن بالميكروثانية) / 58.",
    ],
    warning: "على ESP32: دبوس Echo يعطي 5V! استخدم محول مستوى جهد أو قسم جهد (1K + 2K) لحماية ESP32.",
    tip: "أضف تأخير 60ms بين القراءات لمنع التداخل. الحساس لا يعمل جيداً مع الأسطح الماصة للصوت (القماش) أو الزوايا الحادة.",
    theory: "يرسل الحساس موجة فوق صوتية 40KHz من Trigger ويقيس الوقت حتى ترتد من العائق وتصل لـ Echo. سرعة الصوت 343 م/ث، والمسافة = السرعة x الزمن / 2 (ذهاب وإياب).",
  },
  {
    title: "توصيل حساس الحركة PIR",
    level: "مبتدئ",
    components: ["Arduino Uno", "PIR HC-SR501", "3 أسلاك"],
    steps: [
      "حدد الأطراف (من الخلف): VCC, OUT, GND.",
      "وصّل VCC بـ 5V على Arduino.",
      "وصّل GND بـ GND على Arduino.",
      "وصّل OUT بالدبوس الرقمي 2.",
      "اقرأ الدبوس بـ digitalRead() - HIGH = حركة، LOW = سكون.",
      "اضبط الحساسية ووقت التأخير من المقاومتين المتغيرتين.",
    ],
    warning: "الحساس يحتاج 30-60 ثانية للاستقرار بعد التشغيل (Warm-up). لا تحركه أثناء هذه الفترة.",
    tip: "المقاومة اليمنى تتحكم بالحساسية (المدى). اليسرى تتحكم بوقت بقاء الخرج HIGH بعد كشف الحركة.",
    theory: "PIR يكشف الأشعة تحت الحمراء المنبعثة من الأجسام الدافئة (البشر، الحيوانات). يحتوي على عنصرين حساسين - عند مرور جسم يتغير الفرق بينهما فيرسل إشارة. لا يقيس المسافة، فقط يكشف الحركة.",
  },
  {
    title: "توصيل وحدة الريلاي",
    level: "متقدم",
    components: ["Arduino أو ESP32", "Relay Module 5V", "جهاز كهربائي", "أسلاك"],
    steps: [
      "وصّل VCC بـ 5V و GND بـ GND على اللوحة.",
      "وصّل IN بالدبوس الرقمي المطلوب (مثل D7).",
      "على الجانب الآخر: وصّل سلك الجهاز الكهربائي بـ COM (المشترك).",
      "وصّل الطرف الآخر بـ NO (Normally Open) لتشغيل عند HIGH.",
      "أو بـ NC (Normally Closed) لإيقاف عند HIGH.",
      "استخدم digitalWrite(pin, LOW) لتشغيل الريلاي (Active Low في معظم الوحدات).",
    ],
    warning: "خطر! الريلاي يتعامل مع جهد 220V AC. لا تلمس الأسلاك المكشوفة. تأكد من فصل الكهرباء تماماً قبل أي تعديل. استعن بشخص ذو خبرة.",
    tip: "استخدم وحدات ريلاي مع Optocoupler لعزل كهربائي أفضل بين الدائرة المنخفضة والعالية. ولا تشغل أكثر من ريلاي واحد من Arduino مباشرة.",
    theory: "الريلاي مفتاح كهرومغناطيسي: ملف يولد مجالاً مغناطيسياً يحرك ذراعاً معدنياً لتوصيل أو فصل الدائرة. يسمح بالتحكم بأجهزة الجهد العالي (220V) من لوحة الجهد المنخفض (5V) بأمان.",
  },
  {
    title: "توصيل شاشة OLED SSD1306",
    level: "متوسط",
    components: ["Arduino أو ESP32", "OLED 0.96\" SSD1306", "4 أسلاك"],
    steps: [
      "وصّل GND بـ GND على اللوحة.",
      "وصّل VCC بـ 3.3V أو 5V (حسب الموديل).",
      "وصّل SDA بـ A4 (Arduino) أو GPIO 21 (ESP32).",
      "وصّل SCL بـ A5 (Arduino) أو GPIO 22 (ESP32).",
      "ثبّت مكتبات Adafruit SSD1306 و Adafruit GFX.",
      "أنشئ كائن: Adafruit_SSD1306 display(128, 64, &Wire).",
    ],
    warning: "تحقق من جهد VCC المطلوب من الوحدة. بعض الوحدات 3.3V فقط وتوصيل 5V يحرقها.",
    tip: "مكتبة U8g2 بديل ممتاز يدعم خطوط عربية. استخدم display.clearDisplay() قبل كل إطار جديد.",
    theory: "OLED (Organic LED) كل بكسل يضيء بشكل مستقل بدون إضاءة خلفية. لذلك الأسود الحقيقي = البكسل مطفأ = توفير طاقة. دقة 128x64 بكسل تكفي لعرض نصوص ورسومات بسيطة.",
  },
]

const safetyTips = [
  { icon: Zap, title: "الجهد", text: "لا تتجاوز الجهد المسموح. Arduino = 5V، ESP32 = 3.3V. تجاوز الجهد = احتراق فوري." },
  { icon: Shield, title: "المقاومات", text: "استخدم مقاومات حماية مع LED (220 أوم) ومقاومات Pull-up مع الحساسات (10K)." },
  { icon: AlertTriangle, title: "الطاقة", text: "افصل الطاقة دائماً قبل تعديل التوصيلات. لا تغير الأسلاك واللوحة تعمل." },
  { icon: Info, title: "البريدبورد", text: "ابدأ دائماً بالبريدبورد قبل اللحام. تحقق من التوصيلات مرتين قبل التشغيل." },
  { icon: CircuitBoard, title: "التيار", text: "لا تسحب أكثر من 40mA من دبوس واحد أو 500mA إجمالي من Arduino عبر USB." },
  { icon: Cable, title: "القصر الكهربائي", text: "تأكد من عدم تلامس الأسلاك المكشوفة. القصر الكهربائي يحرق اللوحة والقطع." },
]

export default function WiringPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-12 lg:py-16">
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">دليل التوصيل والإرشاد</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          كل ما تحتاج معرفته عن التوصيلات الكهربائية مع شرح نظري وعملي
        </p>
      </div>

      {/* Safety Tips */}
      <Card className="mb-8 border-destructive/20 bg-destructive/3">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            قواعد الأمان الأساسية
          </CardTitle>
          <CardDescription>احفظ هذه القواعد جيداً قبل البدء بأي توصيل</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {safetyTips.map((tip) => (
              <div key={tip.title} className="flex items-start gap-3 rounded-lg border border-border bg-card p-3">
                <tip.icon className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
                <div>
                  <h4 className="text-sm font-semibold text-foreground">{tip.title}</h4>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{tip.text}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Fundamentals */}
      <div className="mb-8">
        <h2 className="mb-4 flex items-center gap-2 text-xl font-bold text-foreground">
          <BookOpen className="h-5 w-5 text-primary" />
          أساسيات يجب معرفتها
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {fundamentals.map((item) => (
            <Card key={item.title} className="border-border bg-card">
              <CardContent className="pt-5">
                <h3 className="mb-2 text-sm font-semibold text-foreground">{item.title}</h3>
                <p className="text-xs leading-relaxed text-muted-foreground">{item.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Wiring Guides */}
      <h2 className="mb-4 flex items-center gap-2 text-xl font-bold text-foreground">
        <Cable className="h-5 w-5 text-primary" />
        شروحات التوصيل خطوة بخطوة
      </h2>
      <div className="flex flex-col gap-6">
        {wiringGuides.map((guide) => (
          <Card key={guide.title} className="border-border bg-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Cable className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-foreground">{guide.title}</CardTitle>
                    <div className="mt-1 flex flex-wrap gap-1.5">
                      {guide.components.map((c) => (
                        <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <Badge variant="outline" className="border-border text-muted-foreground">{guide.level}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {/* Theory */}
              <div className="mb-4 rounded-lg border border-primary/20 bg-primary/3 p-3">
                <h4 className="mb-1 text-xs font-semibold text-primary">كيف يعمل؟</h4>
                <p className="text-xs leading-relaxed text-foreground">{guide.theory}</p>
              </div>

              {/* Steps */}
              <h4 className="mb-2 text-sm font-semibold text-foreground">خطوات التوصيل:</h4>
              <ol className="mb-4 flex flex-col gap-2">
                {guide.steps.map((step, i) => (
                  <li key={step} className="flex items-start gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                      {i + 1}
                    </span>
                    <span className="text-sm leading-relaxed text-foreground">{step}</span>
                  </li>
                ))}
              </ol>

              {/* Warning */}
              <div className="mb-3 flex items-start gap-2 rounded-lg border border-destructive/20 bg-destructive/3 p-3">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                <div>
                  <span className="text-xs font-semibold text-destructive">تحذير: </span>
                  <span className="text-xs text-foreground">{guide.warning}</span>
                </div>
              </div>

              {/* Tip */}
              <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/3 p-3">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div>
                  <span className="text-xs font-semibold text-primary">نصيحة: </span>
                  <span className="text-xs text-foreground">{guide.tip}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
