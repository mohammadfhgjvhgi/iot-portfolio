import { CommunityFeed } from "@/components/community-feed"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "ملتقى المبدعين | مشاريع التحكم الدقيق",
  description: "شارك مشاريعك وتبادل الخبرات مع مجتمع الطلاب والمبتكرين في عالم الأنظمة المدمجة",
}

export default function CommunityPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 lg:py-16">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-foreground lg:text-4xl">ملتقى المبدعين</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          شارك مشاريعك وتبادل الخبرات والأسئلة مع مجتمع الطلاب والمبتكرين
        </p>
      </div>
      <CommunityFeed />
    </div>
  )
}
